// This is a simple API route to provide the Google Maps API key
// This helps keep your API key more secure by not exposing it directly in client code

export async function GET() {
  // Get the API key from environment variables
  const apiKey = process.env.GOOGLE_MAPS_API_KEY || ""

  return new Response(JSON.stringify({ apiKey }), {
    headers: {
      "Content-Type": "application/json",
    },
  })
}
