"use client"

import Link from "next/link"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PawPrint, User, ArrowLeft, Calendar, MapPin } from "lucide-react"
import { PhotoUploader } from "@/components/photo-uploader"
import { DatePicker } from "@/components/date-picker"
import { MeshGradientBackground } from "@/components/mesh-gradient-background"
import { MultiPinMap } from "@/components/multi-pin-map"

interface Pin {
  id: string
  lat: number
  lng: number
  type: "person" | "pet"
  note: string
  timestamp: string
}

export default function ReportMissingPage() {
  const [locationPins, setLocationPins] = useState<Pin[]>([])
  const [activeTab, setActiveTab] = useState<"person" | "pet">("person")

  return (
    <div className="relative min-h-screen bg-[#fcfcfd]">
      <div className="absolute inset-0 opacity-20">
        <MeshGradientBackground colors={["#f9a8d4", "#ddd6fe", "#bfdbfe", "#a7f3d0"]} speed={0.001} />
      </div>
      <div className="px-4 py-6 relative z-10">
        <Link href="/" className="inline-flex items-center text-sm font-medium mb-4 hover:underline text-[#6b7280]">
          <ArrowLeft className="mr-1 h-4 w-4" />
          Back
        </Link>

        <div className="mb-6">
          <h1 className="text-2xl font-bold tracking-tight mb-2 bg-clip-text text-transparent bg-gradient-to-r from-[#f87c96] to-[#c084fc]">
            Report Missing
          </h1>
          <p className="text-[#6b7280] text-sm">Provide details to help others identify your missing loved one</p>
        </div>

        <Tabs defaultValue="person" className="mb-6" onValueChange={(value) => setActiveTab(value as "person" | "pet")}>
          <TabsList className="grid w-full grid-cols-2 mb-4 bg-white/50 backdrop-blur-sm">
            <TabsTrigger
              value="person"
              className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#f9a8d4]/30 data-[state=active]:to-[#ddd6fe]/30"
            >
              <User className="h-4 w-4" />
              Person
            </TabsTrigger>
            <TabsTrigger
              value="pet"
              className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#ddd6fe]/30 data-[state=active]:to-[#bfdbfe]/30"
            >
              <PawPrint className="h-4 w-4" />
              Pet
            </TabsTrigger>
          </TabsList>

          <TabsContent value="person">
            <Card className="bg-white/80 backdrop-blur-sm border-[#f0f0f5]">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg text-[#374151]">Missing Person Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      placeholder="Enter full name"
                      className="border-[#e5e7eb] focus-visible:ring-[#c084fc]"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="age">Age</Label>
                      <Input
                        id="age"
                        type="number"
                        placeholder="Age"
                        className="border-[#e5e7eb] focus-visible:ring-[#c084fc]"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Gender</Label>
                      <RadioGroup defaultValue="female" className="flex gap-4">
                        <div className="flex items-center space-x-1">
                          <RadioGroupItem value="female" id="female" />
                          <Label htmlFor="female" className="text-sm">
                            Female
                          </Label>
                        </div>
                        <div className="flex items-center space-x-1">
                          <RadioGroupItem value="male" id="male" />
                          <Label htmlFor="male" className="text-sm">
                            Male
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Photos</Label>
                    <PhotoUploader />
                  </div>

                  <div className="space-y-2">
                    <Label className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      Date Last Seen
                    </Label>
                    <DatePicker />
                  </div>

                  <div className="space-y-2">
                    <Label className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      Last Seen Location(s)
                    </Label>
                    <div className="space-y-3">
                      <MultiPinMap
                        height="300px"
                        initialCenter={{ lat: 38.5382, lng: -121.7617 }} // UC Davis coordinates
                        zoom={15} // Higher zoom level for campus view
                        onPinsChange={setLocationPins}
                      />
                      {locationPins.length === 0 ? (
                        <p className="text-xs text-muted-foreground">
                          Add markers to mark locations where the person was last seen. Click the + button and then
                          click on the map.
                        </p>
                      ) : (
                        <p className="text-xs text-muted-foreground">
                          {locationPins.length} location{locationPins.length !== 1 ? "s" : ""} marked on the map.
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Physical Description</Label>
                    <Textarea
                      id="description"
                      placeholder="Height, weight, hair color, clothing, etc."
                      rows={3}
                      className="border-[#e5e7eb] focus-visible:ring-[#c084fc]"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="contact">Your Contact Information</Label>
                    <Input
                      id="contact-phone"
                      placeholder="Phone number"
                      type="tel"
                      className="border-[#e5e7eb] focus-visible:ring-[#c084fc]"
                    />
                    <div className="mt-2">
                      <Input
                        id="contact-email"
                        placeholder="Email address"
                        type="email"
                        className="border-[#e5e7eb] focus-visible:ring-[#c084fc]"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col space-y-2">
                <Button className="w-full bg-gradient-to-r from-[#f87c96] to-[#c084fc] hover:opacity-90">
                  Submit Report
                </Button>
                <Button variant="outline" className="w-full border-[#e5e7eb] text-[#6b7280] hover:bg-[#f9fafb]">
                  Save Draft
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="pet">
            <Card className="bg-white/80 backdrop-blur-sm border-[#f0f0f5]">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg text-[#374151]">Missing Pet Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="pet-name">Pet's Name</Label>
                    <Input
                      id="pet-name"
                      placeholder="Enter pet's name"
                      className="border-[#e5e7eb] focus-visible:ring-[#c084fc]"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="pet-type">Type of Pet</Label>
                      <Input
                        id="pet-type"
                        placeholder="Dog, Cat, etc."
                        className="border-[#e5e7eb] focus-visible:ring-[#c084fc]"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="breed">Breed</Label>
                      <Input
                        id="breed"
                        placeholder="Enter breed"
                        className="border-[#e5e7eb] focus-visible:ring-[#c084fc]"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Photos</Label>
                    <PhotoUploader />
                  </div>

                  <div className="space-y-2">
                    <Label className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      Date Last Seen
                    </Label>
                    <DatePicker />
                  </div>

                  <div className="space-y-2">
                    <Label className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      Last Seen Location(s)
                    </Label>
                    <div className="space-y-3">
                      <MultiPinMap
                        height="300px"
                        initialCenter={{ lat: 38.5382, lng: -121.7617 }} // UC Davis coordinates
                        zoom={15} // Higher zoom level for campus view
                        onPinsChange={setLocationPins}
                      />
                      {locationPins.length === 0 ? (
                        <p className="text-xs text-muted-foreground">
                          Add markers to mark locations where the pet was last seen. Click the + button and then click
                          on the map.
                        </p>
                      ) : (
                        <p className="text-xs text-muted-foreground">
                          {locationPins.length} location{locationPins.length !== 1 ? "s" : ""} marked on the map.
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Physical Description</Label>
                    <Textarea
                      id="description"
                      placeholder="Color, size, distinguishing features, etc."
                      rows={3}
                      className="border-[#e5e7eb] focus-visible:ring-[#c084fc]"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="contact">Your Contact Information</Label>
                    <Input
                      id="contact-phone"
                      placeholder="Phone number"
                      type="tel"
                      className="border-[#e5e7eb] focus-visible:ring-[#c084fc]"
                    />
                    <div className="mt-2">
                      <Input
                        id="contact-email"
                        placeholder="Email address"
                        type="email"
                        className="border-[#e5e7eb] focus-visible:ring-[#c084fc]"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col space-y-2">
                <Button className="w-full bg-gradient-to-r from-[#f87c96] to-[#c084fc] hover:opacity-90">
                  Submit Report
                </Button>
                <Button variant="outline" className="w-full border-[#e5e7eb] text-[#6b7280] hover:bg-[#f9fafb]">
                  Save Draft
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
