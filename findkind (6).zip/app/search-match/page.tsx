"use client"

import Link from "next/link"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { ArrowLeft, Search, Upload, MapPin } from "lucide-react"
import { PhotoUploader } from "@/components/photo-uploader"
import { MeshGradientBackground } from "@/components/mesh-gradient-background"
import { CdnLeafletMap } from "@/components/cdn-leaflet-map"

export default function SearchMatchPage() {
  const [locationData, setLocationData] = useState<{ lat: number; lng: number; address: string } | null>(null)

  return (
    <div className="relative min-h-screen bg-[#fcfcfd]">
      <div className="absolute inset-0 opacity-20">
        <MeshGradientBackground colors={["#bfdbfe", "#ddd6fe", "#f9a8d4", "#a7f3d0"]} speed={0.001} />
      </div>
      <div className="px-4 py-6 relative z-10">
        <Link href="/" className="inline-flex items-center text-sm font-medium mb-4 hover:underline text-[#6b7280]">
          <ArrowLeft className="mr-1 h-4 w-4" />
          Back
        </Link>

        <div className="mb-6">
          <h1 className="text-2xl font-bold tracking-tight mb-2 bg-clip-text text-transparent bg-gradient-to-r from-[#60a5fa] to-[#34d399]">
            Search & Match
          </h1>
          <p className="text-[#6b7280] text-sm">Upload a photo and details to search for matches in our database</p>
        </div>

        <Card className="bg-white/80 backdrop-blur-sm border-[#f0f0f5]">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg text-[#374151]">Search Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="flex items-center gap-1">
                <Upload className="h-4 w-4" />
                Upload Photo
              </Label>
              <PhotoUploader maxPhotos={1} />
              <p className="text-xs text-[#6b7280]">Upload a clear photo to help with matching</p>
            </div>

            <div className="space-y-2">
              <Label>Search Type</Label>
              <RadioGroup defaultValue="person" className="flex gap-4">
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="person" id="search-person" />
                  <Label htmlFor="search-person" className="text-sm">
                    Person
                  </Label>
                </div>
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="pet" id="search-pet" />
                  <Label htmlFor="search-pet" className="text-sm">
                    Pet
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Provide any details that might help with matching (appearance, clothing, etc.)"
                rows={3}
                className="border-[#e5e7eb] focus-visible:ring-[#60a5fa]"
              />
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-1">
                <MapPin className="h-4 w-4" />
                Location Where Seen
              </Label>
              <div className="rounded-md overflow-hidden">
                <CdnLeafletMap
                  height="250px"
                  initialCenter={{ lat: 38.5382, lng: -121.7617 }} // UC Davis coordinates
                  zoom={15} // Higher zoom level for campus view
                  onPinDrop={(location) => {
                    console.log("Search location:", location)
                    setLocationData(location)
                  }}
                />
              </div>
              {locationData ? (
                <p className="text-xs text-muted-foreground">Selected: {locationData.address}</p>
              ) : (
                <p className="text-xs text-muted-foreground">
                  Search for any location (e.g., "UC Davis Quad", "New York", "San Francisco") or click on the map to
                  drop a pin.
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="additional-info">Additional Information</Label>
              <Textarea
                id="additional-info"
                placeholder="Any other details that might help with identification"
                rows={2}
                className="border-[#e5e7eb] focus-visible:ring-[#60a5fa]"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contact">Your Contact Information (Optional)</Label>
              <Input
                id="contact-phone"
                placeholder="Phone number"
                type="tel"
                className="border-[#e5e7eb] focus-visible:ring-[#60a5fa]"
              />
              <div className="mt-2">
                <Input
                  id="contact-email"
                  placeholder="Email address"
                  type="email"
                  className="border-[#e5e7eb] focus-visible:ring-[#60a5fa]"
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col space-y-2">
            <Button
              className="w-full bg-gradient-to-r from-[#60a5fa] to-[#34d399] hover:opacity-90"
              disabled={!locationData}
            >
              <Search className="mr-2 h-4 w-4" />
              Search for Matches
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
