"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { MapPin, X, Search, Locate } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface CdnLeafletMapProps {
  onPinDrop?: (location: { lat: number; lng: number; address: string }) => void
  initialCenter?: { lat: number; lng: number }
  height?: string
  zoom?: number
}

// A comprehensive geocoding database including universities, landmarks, and neighborhoods
const GEOCODING_DB = {
  // Major US Cities
  "new york": { lat: 40.7128, lng: -74.006 },
  "los angeles": { lat: 34.0522, lng: -118.2437 },
  chicago: { lat: 41.8781, lng: -87.6298 },
  houston: { lat: 29.7604, lng: -95.3698 },
  phoenix: { lat: 33.4484, lng: -112.074 },
  philadelphia: { lat: 39.9526, lng: -75.1652 },
  "san antonio": { lat: 29.4241, lng: -98.4936 },
  "san diego": { lat: 32.7157, lng: -117.1611 },
  dallas: { lat: 32.7767, lng: -96.797 },
  "san francisco": { lat: 37.7749, lng: -122.4194 },
  austin: { lat: 30.2672, lng: -97.7431 },
  seattle: { lat: 47.6062, lng: -122.3321 },
  boston: { lat: 42.3601, lng: -71.0589 },
  miami: { lat: 25.7617, lng: -80.1918 },

  // International Cities
  london: { lat: 51.5074, lng: -0.1278 },
  paris: { lat: 48.8566, lng: 2.3522 },
  tokyo: { lat: 35.6762, lng: 139.6503 },
  sydney: { lat: -33.8688, lng: 151.2093 },
  berlin: { lat: 52.52, lng: 13.405 },
  rome: { lat: 41.9028, lng: 12.4964 },

  // Universities
  "uc davis": { lat: 38.5382, lng: -121.7617 },
  "uc berkeley": { lat: 37.8719, lng: -122.2585 },
  "uc los angeles": { lat: 34.0689, lng: -118.4452 },
  ucla: { lat: 34.0689, lng: -118.4452 },
  "uc irvine": { lat: 33.6405, lng: -117.8443 },
  "uc san diego": { lat: 32.8801, lng: -117.234 },
  "uc santa barbara": { lat: 34.414, lng: -119.8489 },
  "uc santa cruz": { lat: 36.9916, lng: -122.0583 },
  "uc riverside": { lat: 33.9737, lng: -117.3281 },
  "uc merced": { lat: 37.366, lng: -120.4235 },
  stanford: { lat: 37.4275, lng: -122.1697 },
  harvard: { lat: 42.377, lng: -71.1167 },
  mit: { lat: 42.3601, lng: -71.0942 },
  yale: { lat: 41.3163, lng: -72.9223 },
  princeton: { lat: 40.3431, lng: -74.6551 },
  columbia: { lat: 40.8075, lng: -73.9626 },
  nyu: { lat: 40.7295, lng: -73.9965 },

  // Landmarks
  "statue of liberty": { lat: 40.6892, lng: -74.0445 },
  "golden gate bridge": { lat: 37.8199, lng: -122.4783 },
  "eiffel tower": { lat: 48.8584, lng: 2.2945 },
  "big ben": { lat: 51.5007, lng: -0.1246 },
  "taj mahal": { lat: 27.1751, lng: 78.0421 },
  "great wall of china": { lat: 40.4319, lng: 116.5704 },
  "grand canyon": { lat: 36.1069, lng: -112.1129 },
  "niagara falls": { lat: 43.0962, lng: -79.0377 },
  "mount rushmore": { lat: 43.8791, lng: -103.4591 },
  yellowstone: { lat: 44.428, lng: -110.5885 },
  yosemite: { lat: 37.8651, lng: -119.5383 },

  // California Specific
  sacramento: { lat: 38.5816, lng: -121.4944 },
  davis: { lat: 38.5449, lng: -121.7405 },
  "san jose": { lat: 37.3382, lng: -121.8863 },
  oakland: { lat: 37.8044, lng: -122.2711 },
  fresno: { lat: 36.7378, lng: -119.7871 },
  bakersfield: { lat: 35.3733, lng: -119.0187 },
  "long beach": { lat: 33.7701, lng: -118.1937 },
  anaheim: { lat: 33.8366, lng: -117.9143 },
  "santa ana": { lat: 33.7455, lng: -117.8677 },
  riverside: { lat: 33.9806, lng: -117.3755 },
  stockton: { lat: 37.9577, lng: -121.2908 },
  irvine: { lat: 33.6846, lng: -117.8265 },
  "santa clara": { lat: 37.3541, lng: -121.9552 },
  "palo alto": { lat: 37.4419, lng: -122.143 },
  "mountain view": { lat: 37.3861, lng: -122.0839 },
  berkeley: { lat: 37.8715, lng: -122.273 },

  // Neighborhoods
  manhattan: { lat: 40.7831, lng: -73.9712 },
  brooklyn: { lat: 40.6782, lng: -73.9442 },
  queens: { lat: 40.7282, lng: -73.7949 },
  bronx: { lat: 40.8448, lng: -73.8648 },
  "staten island": { lat: 40.5795, lng: -74.1502 },
  hollywood: { lat: 34.0928, lng: -118.3287 },
  "venice beach": { lat: 33.985, lng: -118.4695 },
  "santa monica": { lat: 34.0195, lng: -118.4912 },
  "mission district": { lat: 37.7599, lng: -122.4148 },
  "fisherman's wharf": { lat: 37.808, lng: -122.4177 },
  "chinatown sf": { lat: 37.7941, lng: -122.4078 },
  "north beach": { lat: 37.8001, lng: -122.4091 },
  "haight ashbury": { lat: 37.7692, lng: -122.4481 },
  "nob hill": { lat: 37.793, lng: -122.4161 },
  "russian hill": { lat: 37.801, lng: -122.4194 },
  "pacific heights": { lat: 37.7925, lng: -122.4382 },
  "marina district": { lat: 37.8037, lng: -122.4368 },
  "noe valley": { lat: 37.7502, lng: -122.4337 },
  castro: { lat: 37.7609, lng: -122.435 },
  soma: { lat: 37.7785, lng: -122.3963 },
  "downtown sf": { lat: 37.7749, lng: -122.4194 },
  "financial district": { lat: 37.7946, lng: -122.3999 },
  embarcadero: { lat: 37.7992, lng: -122.3977 },

  // Add more locations to the geocoding database
  "new york city": { lat: 40.7128, lng: -74.006 },
  "san francisco bay area": { lat: 37.7749, lng: -122.4194 },
  "washington dc": { lat: 38.9072, lng: -77.0369 },
  "las vegas": { lat: 36.1699, lng: -115.1398 },
  orlando: { lat: 28.5383, lng: -81.3792 },
  atlanta: { lat: 33.749, lng: -84.388 },
  denver: { lat: 39.7392, lng: -104.9903 },
  "salt lake city": { lat: 40.7608, lng: -111.891 },
  portland: { lat: 45.5051, lng: -122.675 },
  nashville: { lat: 36.1627, lng: -86.7816 },
  "new orleans": { lat: 29.9511, lng: -90.0715 },

  // UC Davis specific locations
  "uc davis memorial union": { lat: 38.542, lng: -121.749 },
  "uc davis arboretum": { lat: 38.5302, lng: -121.7468 },
  "uc davis quad": { lat: 38.5419, lng: -121.7502 },
  "uc davis shields library": { lat: 38.5395, lng: -121.7489 },
  "uc davis mondavi center": { lat: 38.5344, lng: -121.7542 },
  "uc davis activities and recreation center": { lat: 38.5452, lng: -121.7559 },
  "uc davis arc": { lat: 38.5452, lng: -121.7559 },
  "uc davis student community center": { lat: 38.5416, lng: -121.7518 },
  "uc davis silo": { lat: 38.5392, lng: -121.7525 },
  "uc davis death star": { lat: 38.537, lng: -121.7535 }, // Social Sciences & Humanities Building
  "uc davis social sciences": { lat: 38.537, lng: -121.7535 },
  "uc davis wellman hall": { lat: 38.5416, lng: -121.7489 },
  "uc davis olson hall": { lat: 38.5423, lng: -121.7485 },
  "uc davis mrak hall": { lat: 38.5382, lng: -121.752 },
  "uc davis kemper hall": { lat: 38.5365, lng: -121.7555 },
  "uc davis tercero": { lat: 38.5345, lng: -121.7585 },
  "uc davis segundo": { lat: 38.5425, lng: -121.7585 },
  "uc davis cuarto": { lat: 38.5475, lng: -121.7605 },
  "uc davis west village": { lat: 38.5425, lng: -121.7875 },
}

export function CdnLeafletMap({
  onPinDrop,
  initialCenter = { lat: 38.5382, lng: -121.7617 }, // Changed to UC Davis coordinates
  height = "400px",
  zoom = 15, // Increased zoom level for better campus view
}: CdnLeafletMapProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null)
  const [address, setAddress] = useState<string | null>(null)
  const [searchValue, setSearchValue] = useState("")
  const [isMapLoaded, setIsMapLoaded] = useState(false)
  const [isLocatePluginLoaded, setIsLocatePluginLoaded] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [searchError, setSearchError] = useState<string | null>(null)
  const mapRef = useRef<any>(null)
  const markerRef = useRef<any>(null)
  const locateControlRef = useRef<any>(null)
  const tileLayerRef = useRef<any>(null)
  const leafletLoaded = useRef(false)
  const [isLoading, setIsLoading] = useState(true)
  const [mapInitialized, setMapInitialized] = useState(false)
  const [debugInfo, setDebugInfo] = useState<string | null>(null)
  const [fallbackMode, setFallbackMode] = useState(false)
  const fallbackMapRef = useRef<HTMLDivElement>(null)
  const [fallbackMarker, setFallbackMarker] = useState<{ x: number; y: number } | null>(null)
  const isMounted = useRef(true)
  const [isGettingLocation, setIsGettingLocation] = useState(false)

  // Set up the isMounted ref for cleanup
  useEffect(() => {
    isMounted.current = true
    return () => {
      isMounted.current = false
    }
  }, [])

  // Load Leaflet scripts and CSS
  useEffect(() => {
    if (leafletLoaded.current) return
    leafletLoaded.current = true
    setIsLoading(true)

    // Check if Leaflet is already loaded
    if (typeof window !== "undefined" && (window as any).L) {
      if (isMounted.current) {
        setIsMapLoaded(true)
        setIsLoading(false)
      }
      return
    }

    // Add Leaflet CSS
    const linkEl = document.createElement("link")
    linkEl.rel = "stylesheet"
    linkEl.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
    linkEl.integrity = "sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
    linkEl.crossOrigin = ""
    document.head.appendChild(linkEl)

    // Add Leaflet JS
    const scriptEl = document.createElement("script")
    scriptEl.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
    scriptEl.integrity = "sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="
    scriptEl.crossOrigin = ""

    scriptEl.onload = () => {
      if (isMounted.current) {
        setIsMapLoaded(true)

        // Now load the Leaflet.Locate plugin
        const locateCSS = document.createElement("link")
        locateCSS.rel = "stylesheet"
        locateCSS.href = "https://cdn.jsdelivr.net/npm/leaflet.locatecontrol@0.79.0/dist/L.Control.Locate.min.css"
        document.head.appendChild(locateCSS)

        const locateScript = document.createElement("script")
        locateScript.src = "https://cdn.jsdelivr.net/npm/leaflet.locatecontrol@0.79.0/dist/L.Control.Locate.min.js"

        locateScript.onload = () => {
          if (isMounted.current) {
            setIsLocatePluginLoaded(true)
            setIsLoading(false)
          }
        }

        locateScript.onerror = () => {
          if (isMounted.current) {
            console.warn("Failed to load Leaflet.Locate plugin. Location button will not be available.")
            setIsLoading(false)
          }
        }

        document.head.appendChild(locateScript)
      }
    }

    scriptEl.onerror = () => {
      if (isMounted.current) {
        setError("Failed to load Leaflet. Using fallback map.")
        setIsLoading(false)
        setFallbackMode(true)
      }
    }

    document.head.appendChild(scriptEl)

    // Set a timeout to handle cases where the script might hang
    const timeoutId = setTimeout(() => {
      if (!isMapLoaded && isMounted.current) {
        setError("Leaflet loading timed out. Using fallback map.")
        setIsLoading(false)
        setFallbackMode(true)
      }
    }, 5000)

    return () => {
      clearTimeout(timeoutId)
    }
  }, [isMapLoaded])

  // Initialize map once Leaflet is loaded
  useEffect(() => {
    if (!isMapLoaded || !mapContainerRef.current || mapRef.current) return

    try {
      // Access the Leaflet object from the window
      const L = (window as any).L
      if (!L) {
        if (isMounted.current) {
          setError("Leaflet not found. Using fallback map.")
          setFallbackMode(true)
        }
        return
      }

      // Create map with better initial options
      const map = L.map(mapContainerRef.current, {
        center: [initialCenter.lat, initialCenter.lng],
        zoom: zoom,
        zoomControl: true,
        attributionControl: true,
        scrollWheelZoom: true,
        dragging: true,
        tap: true,
        zoomAnimation: true,
      })

      // Add tile layer with higher max zoom
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
        minZoom: 3,
      }).addTo(map)

      // Create a custom icon for better visibility
      const customIcon = L.icon({
        iconUrl:
          "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IndoaXRlIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgY2xhc3M9Imx1Y2lkZSBsdWNpZGUtbWFwLXBpbiI+PHBhdGggZmlsbD0iI2VmNDQ0NCIgZD0iTTIwIDEwYzAgNC40Mi04IDggLTggOHMtOC0zLjU4LTgtOGE4IDggMCAxIDEgMTYgMHoiPjwvcGF0aD48Y2lyY2xlIGN4PSIxMiIgY3k9IjEwIiByPSIzIiBmaWxsPSJ3aGl0ZSI+PC9jaXJjbGU+PC9zdmc+",
        iconSize: [32, 32],
        iconAnchor: [16, 32],
        popupAnchor: [0, -32],
      })

      // Set up click handler for dropping pins
      map.on("click", (e: any) => {
        if (!isMounted.current) return

        const { lat, lng } = e.latlng

        // Remove existing marker if any
        if (markerRef.current) {
          map.removeLayer(markerRef.current)
        }

        // Create a new marker with custom icon
        const marker = L.marker([lat, lng], { icon: customIcon }).addTo(map)
        markerRef.current = marker

        // Generate address string
        const addressStr = `Location at ${lat.toFixed(6)}, ${lng.toFixed(6)}`
        setAddress(addressStr)

        // Add a popup to the marker
        marker.bindPopup(addressStr).openPopup()

        // Call the callback
        if (onPinDrop) {
          onPinDrop({
            lat,
            lng,
            address: addressStr,
          })
        }
      })

      mapRef.current = map

      // Add location found/error event handlers directly to the map
      map.on("locationfound", (e: any) => {
        if (!isMounted.current) return
        console.log("Location found event triggered", e)

        setIsGettingLocation(false)
        handleLocationFound(e.latlng.lat, e.latlng.lng)
      })

      map.on("locationerror", (e: any) => {
        if (!isMounted.current) return
        console.warn("Location error event triggered:", e.message)

        setIsGettingLocation(false)
        handleGeolocationError(e)
      })

      // Trigger a resize event after the map is initialized
      setTimeout(() => {
        if (map && isMounted.current) {
          map.invalidateSize()
        }
      }, 100)

      return () => {
        if (map) {
          map.remove()
        }
        mapRef.current = null
        markerRef.current = null
        locateControlRef.current = null
      }
    } catch (err) {
      console.error("Error initializing map:", err)
      if (isMounted.current) {
        setError("Error initializing map. Using fallback map.")
        setFallbackMode(true)
      }
    }
  }, [isMapLoaded, initialCenter, onPinDrop, zoom])

  // Enhanced geocoding function with fuzzy matching
  const geocodeLocation = (query: string) => {
    // Clean up the query
    const cleanQuery = query.toLowerCase().trim()

    // Direct match
    if (GEOCODING_DB[cleanQuery]) {
      return {
        coords: GEOCODING_DB[cleanQuery],
        name: cleanQuery,
      }
    }

    // Check for partial matches
    for (const [key, coords] of Object.entries(GEOCODING_DB)) {
      // Check if the query is contained in the key or vice versa
      if (key.includes(cleanQuery) || cleanQuery.includes(key)) {
        return {
          coords,
          name: key,
        }
      }
    }

    // Check for word matches (for multi-word queries)
    const queryWords = cleanQuery.split(/\s+/)
    if (queryWords.length > 1) {
      // Try to match each word
      for (const [key, coords] of Object.entries(GEOCODING_DB)) {
        const keyWords = key.split(/\s+/)

        // Count how many words match
        let matchCount = 0
        for (const queryWord of queryWords) {
          if (queryWord.length < 3) continue // Skip very short words

          for (const keyWord of keyWords) {
            if (keyWord.includes(queryWord) || queryWord.includes(keyWord)) {
              matchCount++
              break
            }
          }
        }

        // If more than half of the words match, consider it a match
        if (matchCount >= Math.ceil(queryWords.length / 2)) {
          return {
            coords,
            name: key,
          }
        }
      }
    }

    // If we still can't find a match, try to find any partial word match
    for (const [key, coords] of Object.entries(GEOCODING_DB)) {
      for (const queryWord of queryWords) {
        if (queryWord.length < 3) continue // Skip very short words

        if (key.includes(queryWord)) {
          return {
            coords,
            name: key,
          }
        }
      }
    }

    // If we still can't find a match, return null
    return null
  }

  // Handle search - works for both real and fallback maps
  const handleSearch = () => {
    setSearchError(null)

    if (!searchValue.trim()) return

    // Try to geocode the location
    const result = geocodeLocation(searchValue)

    if (result) {
      const { coords, name } = result

      if (!fallbackMode && mapRef.current) {
        try {
          const map = mapRef.current

          // First remove existing marker if any
          if (markerRef.current) {
            map.removeLayer(markerRef.current)
            markerRef.current = null
          }

          // Create a new marker
          const L = (window as any).L

          // Create a custom icon for better visibility
          const customIcon = L.icon({
            iconUrl:
              "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IndoaXRlIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgY2xhc3M9Imx1Y2lkZSBsdWNpZGUtbWFwLXBpbiI+PHBhdGggZmlsbD0iI2VmNDQ0NCIgZD0iTTIwIDEwYzAgNC40Mi04IDggLTggOHMtOC0zLjU4LTgtOGE4IDggMCAxIDEgMTYgMHoiPjwvcGF0aD48Y2lyY2xlIGN4PSIxMiIgY3k9IjEwIiByPSIzIiBmaWxsPSJ3aGl0ZSI+PC9jaXJjbGU+PC9zdmc+",
            iconSize: [32, 32],
            iconAnchor: [16, 32],
            popupAnchor: [0, -32],
          })

          // Create the marker first
          const marker = L.marker([coords.lat, coords.lng], { icon: customIcon }).addTo(map)
          markerRef.current = marker

          // Generate address string - use the original search value for better UX
          const addressStr = `${searchValue} (${coords.lat.toFixed(6)}, ${coords.lng.toFixed(6)})`
          setAddress(addressStr)

          // Add a popup to the marker
          marker.bindPopup(addressStr).openPopup()

          // IMPORTANT: Set the view AFTER creating the marker to ensure proper centering
          // Use setView instead of flyTo for more reliable positioning
          map.setView([coords.lat, coords.lng], 15, {
            animate: true,
          })

          // Force a map redraw to ensure everything is displayed correctly
          setTimeout(() => {
            if (map && isMounted.current) {
              map.invalidateSize()
            }
          }, 100)

          // Call the callback
          if (onPinDrop) {
            onPinDrop({
              lat: coords.lat,
              lng: coords.lng,
              address: addressStr,
            })
          }

          return
        } catch (err) {
          console.error("Error during map search:", err)
        }
      } else if (fallbackMode && fallbackMapRef.current) {
        // For the fallback map, we'll simulate the location by placing a marker
        // in the center of the map
        const width = fallbackMapRef.current.clientWidth
        const height = fallbackMapRef.current.clientHeight

        // Place marker in the center
        setFallbackMarker({ x: width / 2, y: height / 2 })

        // Generate address string
        const addressStr = `${searchValue} (${coords.lat.toFixed(6)}, ${coords.lng.toFixed(6)})`
        setAddress(addressStr)

        // Call the callback
        if (onPinDrop) {
          onPinDrop({
            lat: coords.lat,
            lng: coords.lng,
            address: addressStr,
          })
        }

        return
      }
    }

    // If we get here, the location wasn't found
    setSearchError(`Location "${searchValue}" not found. Try a different search term.`)
    setTimeout(() => {
      if (isMounted.current) {
        setSearchError(null)
      }
    }, 4000)
  }

  // Handle geolocation errors with better user feedback
  const handleGeolocationError = (error: GeolocationPositionError | any) => {
    let errorMessage = "Unable to get your location. Try searching for a location instead."
    let isPermissionError = false

    console.error("Geolocation error:", error)

    if (typeof error === "object" && error.code) {
      switch (error.code) {
        case 1: // PERMISSION_DENIED
          errorMessage = "Location access was denied. Please check your browser settings or try searching instead."
          isPermissionError = true
          break
        case 2: // POSITION_UNAVAILABLE
          errorMessage = "Your current location is unavailable. Please try searching for a location instead."
          break
        case 3: // TIMEOUT
          errorMessage = "Location request timed out. Please try again or search for a location."
          break
      }
    } else if (typeof error === "string") {
      errorMessage = error
    } else if (error && error.message) {
      errorMessage = error.message
    }

    setSearchError(errorMessage)
    setIsGettingLocation(false)

    // Show the error for a longer time for permission errors
    if (isPermissionError) {
      setTimeout(() => {
        if (isMounted.current) {
          setSearchError("To enable location: 1) Check browser settings 2) Allow location access 3) Refresh the page")
        }
      }, 5000)

      setTimeout(() => {
        if (isMounted.current) {
          setSearchError(null)
        }
      }, 10000)
    } else {
      setTimeout(() => {
        if (isMounted.current) {
          setSearchError(null)
        }
      }, 5000)
    }
  }

  // Handle successful location retrieval
  const handleLocationFound = (latitude: number, longitude: number) => {
    console.log(`Location found: ${latitude}, ${longitude}`)

    // Show success message
    setSearchError("Location found successfully!")
    setTimeout(() => {
      if (isMounted.current) {
        setSearchError(null)
      }
    }, 2000)

    if (!fallbackMode && mapRef.current) {
      try {
        const map = mapRef.current
        const L = (window as any).L

        // Animate to the current location
        map.flyTo([latitude, longitude], 15, {
          animate: true,
          duration: 1.5,
        })

        // Remove existing marker if any
        if (markerRef.current) {
          map.removeLayer(markerRef.current)
        }

        // Create a custom icon for the location marker
        const locationIcon = L.icon({
          iconUrl:
            "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IndoaXRlIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgY2xhc3M9Imx1Y2lkZSBsdWNpZGUtbWFwLXBpbiI+PHBhdGggZmlsbD0iIzYwYTVmYSIgZD0iTTIwIDEwYzAgNC40Mi04IDggLTggOHMtOC0zLjU4LTgtOGE4IDggMCAxIDEgMTYgMHoiPjwvcGF0aD48Y2lyY2xlIGN4PSIxMiIgY3k9IjEwIiByPSIzIiBmaWxsPSJ3aGl0ZSI+PC9jaXJjbGU+PC9zdmc+",
          iconSize: [32, 32],
          iconAnchor: [16, 32],
          popupAnchor: [0, -32],
        })

        const marker = L.marker([latitude, longitude], { icon: locationIcon }).addTo(map)
        markerRef.current = marker

        // Generate address string
        const addressStr = `Your current location (${latitude.toFixed(6)}, ${longitude.toFixed(6)})`
        setAddress(addressStr)

        // Add a popup to the marker
        marker.bindPopup(addressStr).openPopup()

        // Call the callback
        if (onPinDrop) {
          onPinDrop({
            lat: latitude,
            lng: longitude,
            address: addressStr,
          })
        }
      } catch (err) {
        console.error("Error getting current location:", err)
        handleGeolocationError("Error displaying current location. Please try again or search instead.")
      }
    } else if (fallbackMode && fallbackMapRef.current) {
      // For fallback map, just place a marker in the center
      const width = fallbackMapRef.current.clientWidth
      const height = fallbackMapRef.current.clientHeight

      setFallbackMarker({ x: width / 2, y: height / 2 })

      // Generate address string
      const addressStr = `Your current location (${latitude.toFixed(6)}, ${longitude.toFixed(6)})`
      setAddress(addressStr)

      // Call the callback
      if (onPinDrop) {
        onPinDrop({
          lat: latitude,
          lng: longitude,
          address: addressStr,
        })
      }
    }
  }

  // Improve the getCurrentLocation function to better handle errors and provide alternatives
  const getCurrentLocation = () => {
    // Clear any existing errors
    setSearchError(null)
    setIsGettingLocation(true)

    // Check if geolocation is available
    if (!navigator.geolocation) {
      setIsGettingLocation(false)
      setSearchError("Geolocation is not supported by your browser. Please search for a location instead.")
      return
    }

    // Show loading indicator with guidance
    setSearchError("Requesting your location... Check browser permissions if prompted.")

    // Try to use the map's locate method first if available
    if (!fallbackMode && mapRef.current) {
      try {
        console.log("Using map.locate() method")
        mapRef.current.locate({
          setView: true,
          maxZoom: 16,
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0,
        })
        return
      } catch (err) {
        console.error("Error using map.locate():", err)
        // Fall back to the browser's geolocation API
      }
    }

    // Use the browser's geolocation API as a fallback
    navigator.geolocation.getCurrentPosition(
      (position) => {
        if (!isMounted.current) return
        setIsGettingLocation(false)

        const { latitude, longitude } = position.coords
        handleLocationFound(latitude, longitude)
      },
      (err) => {
        setIsGettingLocation(false)
        handleGeolocationError(err)
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      },
    )
  }

  // Handle fallback map click
  const handleFallbackMapClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!fallbackMapRef.current) return

    const rect = fallbackMapRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    setFallbackMarker({ x, y })

    // Generate a simulated lat/lng based on the click position
    const width = fallbackMapRef.current.clientWidth
    const height = fallbackMapRef.current.clientHeight

    // Convert pixel position to a simulated lat/lng
    const lat = initialCenter.lat + ((height / 2 - y) / height) * 0.1
    const lng = initialCenter.lng + ((x - width / 2) / width) * 0.1

    // Generate address string
    const addressStr = `Location at ${lat.toFixed(6)}, ${lng.toFixed(6)}`
    setAddress(addressStr)

    // Call the callback
    if (onPinDrop) {
      onPinDrop({
        lat,
        lng,
        address: addressStr,
      })
    }
  }

  // Clear the marker
  const clearMarker = () => {
    if (!fallbackMode && mapRef.current && markerRef.current) {
      try {
        const map = mapRef.current
        map.removeLayer(markerRef.current)
        markerRef.current = null
      } catch (err) {
        console.error("Error clearing marker:", err)
      }
    } else if (fallbackMode) {
      setFallbackMarker(null)
    }

    setAddress(null)

    if (onPinDrop) {
      onPinDrop({ lat: 0, lng: 0, address: "" })
    }
  }

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            placeholder="Search for a location (e.g., UC Davis, New York, etc.)"
            className="pr-10"
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          />
          {searchValue && (
            <button
              className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              onClick={() => setSearchValue("")}
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <Button variant="outline" size="icon" onClick={handleSearch} title="Search location">
          <Search className="h-4 w-4" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={getCurrentLocation}
          className="relative group"
          disabled={isGettingLocation}
          title="Use your current location (requires permission)"
        >
          {isGettingLocation ? (
            <div className="h-4 w-4 animate-spin rounded-full border-2 border-gray-300 border-t-blue-600"></div>
          ) : (
            <Locate className="h-4 w-4" />
          )}
          <span className="absolute -top-10 left-1/2 transform -translate-x-1/2 bg-black text-white text-xs rounded px-2 py-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">
            Use my location
          </span>
        </Button>
      </div>

      {searchError && (
        <Alert
          variant={
            searchError?.includes("successfully")
              ? "success"
              : searchError?.includes("Requesting")
                ? "default"
                : "warning"
          }
          className="py-2"
        >
          <AlertDescription className="text-xs">{searchError}</AlertDescription>
        </Alert>
      )}

      {!fallbackMode && (
        <Alert variant="info" className="py-2 bg-blue-50 border-blue-200 text-blue-800 mb-2">
          <AlertDescription className="text-xs">
            <span className="font-medium">Tip:</span> Click the map to drop a pin at a specific location
          </AlertDescription>
        </Alert>
      )}

      <div style={{ height, width: "100%" }} className="relative rounded-md overflow-hidden border border-gray-200">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-50 z-10">
            <div className="flex flex-col items-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mb-2"></div>
              <p className="text-sm text-gray-600">Loading map...</p>
            </div>
          </div>
        )}

        {error && (
          <div className="absolute inset-0 flex items-center justify-center bg-red-50 p-4 z-10">
            <div className="text-red-500 text-center">
              <p className="font-medium">{error}</p>
              <p className="text-sm mt-2">Please try refreshing the page</p>
            </div>
          </div>
        )}

        <div ref={mapContainerRef} className="h-full w-full"></div>

        {/* Fallback map if Leaflet fails to load */}
        {fallbackMode && (
          <div
            ref={fallbackMapRef}
            className="absolute inset-0 bg-blue-50 cursor-pointer"
            onClick={handleFallbackMapClick}
          >
            <div className="absolute inset-0 grid grid-cols-8 grid-rows-8">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={`row-${i}`} className="border-t border-gray-200" />
              ))}
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={`col-${i}`} className="border-l border-gray-200" />
              ))}
            </div>

            {/* Simulated map features */}
            <div className="absolute inset-0">
              <div className="absolute top-1/4 left-0 right-0 h-1 bg-gray-300"></div>
              <div className="absolute top-3/4 left-0 right-0 h-1 bg-gray-300"></div>
              <div className="absolute left-1/4 top-0 bottom-0 w-1 bg-gray-300"></div>
              <div className="absolute left-3/4 top-0 bottom-0 w-1 bg-gray-300"></div>
              <div className="absolute top-1/2 left-1/2 w-16 h-16 bg-blue-200 rounded-full transform -translate-x-1/2 -translate-y-1/2"></div>
            </div>

            {/* Fallback marker */}
            {fallbackMarker && (
              <div
                className="absolute pointer-events-none"
                style={{
                  left: `${fallbackMarker.x}px`,
                  top: `${fallbackMarker.y}px`,
                  transform: "translate(-50%, -100%)",
                }}
              >
                <MapPin className="h-8 w-8 text-red-500 drop-shadow-md" />
              </div>
            )}

            {!fallbackMarker && !searchValue && (
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
                <MapPin className="h-8 w-8 text-gray-500 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Search for a location or click to drop a pin</p>
              </div>
            )}
          </div>
        )}
      </div>

      {address && (
        <div className="flex items-center justify-between bg-gray-50 p-3 rounded-md border border-gray-200">
          <div className="flex items-start gap-2">
            <MapPin className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium">Dropped Pin</p>
              <p className="text-xs text-gray-500">{address}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={clearMarker} className="h-8 text-gray-500 hover:text-gray-700">
            <X className="h-4 w-4 mr-1" />
            Clear
          </Button>
        </div>
      )}
    </div>
  )
}
