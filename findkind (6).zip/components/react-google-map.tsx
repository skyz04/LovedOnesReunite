"use client"
import { SimpleMapPinDropper } from "@/components/simple-map-pin-dropper"

// Define types for Google Maps objects
type GoogleMap = google.maps.Map
type GoogleMarker = google.maps.Marker
type LatLngLiteral = google.maps.LatLngLiteral
type MapOptions = google.maps.MapOptions

interface ReactGoogleMapProps {
  onPinDrop?: (location: { lat: number; lng: number; address: string }) => void
  initialCenter?: LatLngLiteral
  height?: string
}

// Declare google as a global variable
declare global {
  interface Window {
    google: any
    initMap: () => void
    gm_authFailure?: () => void
  }
}

export function ReactGoogleMap({
  onPinDrop,
  initialCenter = { lat: 37.7749, lng: -122.4194 }, // Default to San Francisco
  height = "400px",
}: ReactGoogleMapProps) {
  // Always use the SimpleMapPinDropper instead of trying to load Google Maps
  // This is a temporary solution until the API quota issues are resolved
  return (
    <div className="space-y-3">
      <div className="bg-amber-50 border border-amber-200 rounded-md p-3 text-sm text-amber-700">
        <p className="font-medium mb-1">Using simplified map</p>
        <p>The Google Maps API is currently unavailable due to quota limitations.</p>
      </div>
      <SimpleMapPinDropper height={height} onPinDrop={onPinDrop} />
    </div>
  )
}
