"use client"

import { useState, useEffect, useRef } from "react"
import { MapContainer, TileLayer, Marker, useMapEvents, Popup } from "react-leaflet"
import { Icon, type LatLngExpression } from "leaflet"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MapPin, Locate, Search, X } from "lucide-react"
import "leaflet/dist/leaflet.css"

// Fix for Leaflet marker icons with webpack
// This is needed because Leaflet's default marker icons reference assets that aren't properly bundled
const markerIcon = new Icon({
  iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
  iconRetinaUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
  shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
})

interface LeafletMapProps {
  onPinDrop?: (location: { lat: number; lng: number; address: string }) => void
  initialCenter?: [number, number]
  height?: string
}

// Component to handle map events
function MapEvents({ onPinDrop }: { onPinDrop: (latlng: { lat: number; lng: number }) => void }) {
  const map = useMapEvents({
    click: (e) => {
      onPinDrop({ lat: e.latlng.lat, lng: e.latlng.lng })
    },
  })
  return null
}

export function LeafletMap({
  onPinDrop,
  initialCenter = [37.7749, -122.4194], // Default to San Francisco
  height = "400px",
}: LeafletMapProps) {
  const [position, setPosition] = useState<LatLngExpression | null>(null)
  const [address, setAddress] = useState<string>("")
  const [searchValue, setSearchValue] = useState("")
  const [isClient, setIsClient] = useState(false)
  const mapRef = useRef(null)

  // This ensures the component only renders on the client
  useEffect(() => {
    setIsClient(true)
  }, [])

  // Function to handle pin dropping
  const handlePinDrop = async (latlng: { lat: number; lng: number }) => {
    setPosition([latlng.lat, latlng.lng])

    // Simulate getting an address (in a real app, you'd use a geocoding service)
    const simulatedAddress = `Location at ${latlng.lat.toFixed(6)}, ${latlng.lng.toFixed(6)}`
    setAddress(simulatedAddress)

    // Call the callback with location data
    if (onPinDrop) {
      onPinDrop({
        lat: latlng.lat,
        lng: latlng.lng,
        address: simulatedAddress,
      })
    }
  }

  // Function to search for a location
  const handleSearch = () => {
    if (!searchValue.trim()) return

    // In a real app, you'd use a geocoding service here
    // For now, we'll just simulate by moving the pin to the center
    const center = initialCenter
    setPosition(center)

    const simulatedAddress = `${searchValue} (simulated location)`
    setAddress(simulatedAddress)

    if (onPinDrop) {
      onPinDrop({
        lat: center[0],
        lng: center[1],
        address: simulatedAddress,
      })
    }
  }

  // Function to get current location
  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords
          setPosition([latitude, longitude])

          const simulatedAddress = `Your current location (${latitude.toFixed(6)}, ${longitude.toFixed(6)})`
          setAddress(simulatedAddress)

          if (onPinDrop) {
            onPinDrop({
              lat: latitude,
              lng: longitude,
              address: simulatedAddress,
            })
          }
        },
        () => {
          alert("Unable to get your location. Please check your device settings.")
        },
      )
    } else {
      alert("Geolocation is not supported by your browser.")
    }
  }

  // Function to clear the marker
  const clearMarker = () => {
    setPosition(null)
    setAddress("")

    if (onPinDrop) {
      onPinDrop({ lat: 0, lng: 0, address: "" })
    }
  }

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            placeholder="Search for a location"
            className="pr-10"
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          />
          {searchValue && (
            <button
              className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              onClick={() => setSearchValue("")}
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <Button variant="outline" size="icon" onClick={handleSearch} title="Search location">
          <Search className="h-4 w-4" />
        </Button>
        <Button variant="outline" size="icon" onClick={getCurrentLocation} title="Use current location">
          <Locate className="h-4 w-4" />
        </Button>
      </div>

      <div style={{ height, width: "100%" }} className="rounded-md overflow-hidden border border-gray-200">
        {isClient ? (
          <MapContainer center={initialCenter} zoom={13} style={{ height: "100%", width: "100%" }} ref={mapRef}>
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <MapEvents onPinDrop={handlePinDrop} />
            {position && (
              <Marker position={position} icon={markerIcon}>
                <Popup>{address}</Popup>
              </Marker>
            )}
          </MapContainer>
        ) : (
          <div className="flex items-center justify-center h-full bg-gray-100">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
          </div>
        )}
      </div>

      {address && (
        <div className="flex items-center justify-between bg-gray-50 p-3 rounded-md border border-gray-200">
          <div className="flex items-start gap-2">
            <MapPin className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium">Dropped Pin</p>
              <p className="text-xs text-gray-500">{address}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={clearMarker} className="h-8 text-gray-500 hover:text-gray-700">
            <X className="h-4 w-4 mr-1" />
            Clear
          </Button>
        </div>
      )}
    </div>
  )
}
