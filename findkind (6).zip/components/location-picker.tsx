"use client"

import { useState } from "react"
import { CdnLeafletMap } from "@/components/cdn-leaflet-map"

interface LocationPickerProps {
  initialLocation?: string
}

export function LocationPicker({ initialLocation }: LocationPickerProps) {
  const [locationData, setLocationData] = useState<{ lat: number; lng: number; address: string } | null>(null)

  return (
    <div className="space-y-2">
      <CdnLeafletMap
        height="200px"
        initialCenter={{ lat: 38.5382, lng: -121.7617 }} // Explicitly set to UC Davis
        zoom={15}
        onPinDrop={(location) => {
          console.log("Location selected:", location)
          setLocationData(location)
        }}
        // If initialLocation is provided, we'll use it as the search value
        // This would be handled by the CdnLeafletMap component's search functionality
      />
      {locationData && <p className="text-xs text-muted-foreground mt-1">Selected: {locationData.address}</p>}
    </div>
  )
}
