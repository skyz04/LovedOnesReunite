"use client"

import { useEffect, useRef, useState } from "react"
import { MapPin, X, Search, Locate, User, PawPrint, Plus, Trash } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"

interface Pin {
  id: string
  lat: number
  lng: number
  type: "person" | "pet"
  note: string
  timestamp: string
}

interface MultiPinMapProps {
  onPinsChange?: (pins: Pin[]) => void
  initialCenter?: { lat: number; lng: number }
  height?: string
  zoom?: number
}

// Reuse the geocoding database from CdnLeafletMap
const GEOCODING_DB = {
  // Major US Cities
  "new york": { lat: 40.7128, lng: -74.006 },
  "los angeles": { lat: 34.0522, lng: -118.2437 },
  chicago: { lat: 41.8781, lng: -87.6298 },
  houston: { lat: 29.7604, lng: -95.3698 },
  phoenix: { lat: 33.4484, lng: -112.074 },
  philadelphia: { lat: 39.9526, lng: -75.1652 },
  "san antonio": { lat: 29.4241, lng: -98.4936 },
  "san diego": { lat: 32.7157, lng: -117.1611 },
  dallas: { lat: 32.7767, lng: -96.797 },
  "san francisco": { lat: 37.7749, lng: -122.4194 },
  austin: { lat: 30.2672, lng: -97.7431 },
  seattle: { lat: 47.6062, lng: -122.3321 },
  boston: { lat: 42.3601, lng: -71.0589 },
  miami: { lat: 25.7617, lng: -80.1918 },

  // UC Davis specific locations
  "uc davis": { lat: 38.5382, lng: -121.7617 },
  "uc davis memorial union": { lat: 38.542, lng: -121.749 },
  "uc davis arboretum": { lat: 38.5302, lng: -121.7468 },
  "uc davis quad": { lat: 38.5419, lng: -121.7502 },
  "uc davis shields library": { lat: 38.5395, lng: -121.7489 },
  "uc davis mondavi center": { lat: 38.5344, lng: -121.7542 },
  "uc davis activities and recreation center": { lat: 38.5452, lng: -121.7559 },
  "uc davis arc": { lat: 38.5452, lng: -121.7559 },
  "uc davis student community center": { lat: 38.5416, lng: -121.7518 },
  "uc davis silo": { lat: 38.5392, lng: -121.7525 },
  "uc davis death star": { lat: 38.537, lng: -121.7535 },
  "uc davis social sciences": { lat: 38.537, lng: -121.7535 },
  "uc davis wellman hall": { lat: 38.5416, lng: -121.7489 },
  "uc davis olson hall": { lat: 38.5423, lng: -121.7485 },
  "uc davis mrak hall": { lat: 38.5382, lng: -121.752 },
  "uc davis kemper hall": { lat: 38.5365, lng: -121.7555 },
  "uc davis tercero": { lat: 38.5345, lng: -121.7585 },
  "uc davis segundo": { lat: 38.5425, lng: -121.7585 },
  "uc davis cuarto": { lat: 38.5475, lng: -121.7605 },
  "uc davis west village": { lat: 38.5425, lng: -121.7875 },

  // Add more locations as needed
  davis: { lat: 38.5449, lng: -121.7405 },
  sacramento: { lat: 38.5816, lng: -121.4944 },
}

export function MultiPinMap({
  onPinsChange,
  initialCenter = { lat: 38.5382, lng: -121.7617 }, // UC Davis coordinates
  height = "400px",
  zoom = 15,
}: MultiPinMapProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null)
  const [searchValue, setSearchValue] = useState("")
  const [isMapLoaded, setIsMapLoaded] = useState(false)
  const [isLocatePluginLoaded, setIsLocatePluginLoaded] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [searchError, setSearchError] = useState<string | null>(null)
  const mapRef = useRef<any>(null)
  const markersRef = useRef<{ [id: string]: any }>({})
  const locateControlRef = useRef<any>(null)
  const leafletLoaded = useRef(false)
  const [isLoading, setIsLoading] = useState(true)
  const [fallbackMode, setFallbackMode] = useState(false)
  const fallbackMapRef = useRef<HTMLDivElement>(null)
  const isMounted = useRef(true)
  const [debugInfo, setDebugInfo] = useState<string | null>(null)
  const [isGettingLocation, setIsGettingLocation] = useState(false)

  // State for pins
  const [pins, setPins] = useState<Pin[]>([])
  const [selectedPin, setSelectedPin] = useState<Pin | null>(null)
  const [newPinType, setNewPinType] = useState<"person" | "pet">("person")
  const [newPinNote, setNewPinNote] = useState("")
  const [isAddingPin, setIsAddingPin] = useState(false)
  const [tempPin, setTempPin] = useState<{ lat: number; lng: number } | null>(null)

  // Set up the isMounted ref for cleanup
  useEffect(() => {
    isMounted.current = true
    return () => {
      isMounted.current = false
    }
  }, [])

  // Load Leaflet scripts and CSS
  useEffect(() => {
    if (leafletLoaded.current) return
    leafletLoaded.current = true
    setIsLoading(true)

    // Check if Leaflet is already loaded
    if (typeof window !== "undefined" && (window as any).L) {
      if (isMounted.current) {
        setIsMapLoaded(true)
        setIsLoading(false)
      }
      return
    }

    // Add Leaflet CSS
    const linkEl = document.createElement("link")
    linkEl.rel = "stylesheet"
    linkEl.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
    linkEl.integrity = "sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
    linkEl.crossOrigin = ""
    document.head.appendChild(linkEl)

    // Add Leaflet JS
    const scriptEl = document.createElement("script")
    scriptEl.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
    scriptEl.integrity = "sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="
    scriptEl.crossOrigin = ""

    scriptEl.onload = () => {
      if (isMounted.current) {
        console.log("Leaflet loaded successfully")
        setIsMapLoaded(true)
        setIsLoading(false)
      }
    }

    scriptEl.onerror = () => {
      if (isMounted.current) {
        console.error("Failed to load Leaflet")
        setError("Failed to load Leaflet. Using fallback map.")
        setIsLoading(false)
        setFallbackMode(true)
      }
    }

    document.head.appendChild(scriptEl)

    // Set a timeout to handle cases where the script might hang
    const timeoutId = setTimeout(() => {
      if (!isMapLoaded && isMounted.current) {
        console.error("Leaflet loading timed out")
        setError("Leaflet loading timed out. Using fallback map.")
        setIsLoading(false)
        setFallbackMode(true)
      }
    }, 5000)

    return () => {
      clearTimeout(timeoutId)
    }
  }, [isMapLoaded])

  // Initialize map once Leaflet is loaded
  useEffect(() => {
    if (!isMapLoaded || !mapContainerRef.current || mapRef.current) return

    try {
      // Access the Leaflet object from the window
      const L = (window as any).L
      if (!L) {
        if (isMounted.current) {
          console.error("Leaflet not found in window object")
          setError("Leaflet not found. Using fallback map.")
          setFallbackMode(true)
        }
        return
      }

      console.log("Initializing map...")

      // Create map with better initial options
      const map = L.map(mapContainerRef.current, {
        center: [initialCenter.lat, initialCenter.lng],
        zoom: zoom,
        zoomControl: true,
        attributionControl: true,
        scrollWheelZoom: true,
        dragging: true,
        tap: true,
        zoomAnimation: true,
      })

      console.log("Map created successfully")

      // Add tile layer with higher max zoom
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
        minZoom: 3,
      }).addTo(map)

      console.log("Tile layer added successfully")

      // Fix for Leaflet default marker icon
      // This is a common issue with Leaflet in React/Next.js
      delete L.Icon.Default.prototype._getIconUrl
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
        iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
        shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
      })

      console.log("Default marker icon fixed")

      // Create custom icons for person and pet markers
      const personIcon = new L.Icon({
        iconUrl: "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png",
        shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowSize: [41, 41],
      })

      const petIcon = new L.Icon({
        iconUrl: "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png",
        shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowSize: [41, 41],
      })

      console.log("Custom icons created")

      // Set up click handler for dropping pins
      map.on("click", (e: any) => {
        if (!isMounted.current) return

        // Only handle clicks when in adding mode
        if (isAddingPin) {
          const { lat, lng } = e.latlng
          console.log(`Map clicked at: ${lat}, ${lng}`)

          // Create a simple marker immediately for visual feedback
          const L = (window as any).L
          const tempMarker = L.marker([lat, lng]).addTo(map)

          // Set the temp pin for the form
          setTempPin({ lat, lng })

          // Scroll to the form if needed
          setTimeout(() => {
            const formElement = document.getElementById("pin-form")
            if (formElement) {
              formElement.scrollIntoView({ behavior: "smooth" })
            }
          }, 100)
        }
      })

      mapRef.current = map

      // Add location found/error event handlers directly to the map
      map.on("locationfound", (e: any) => {
        if (!isMounted.current) return
        console.log("Location found event triggered", e)

        setIsGettingLocation(false)
        handleLocationFound(e.latlng.lat, e.latlng.lng)
      })

      map.on("locationerror", (e: any) => {
        if (!isMounted.current) return
        console.warn("Location error event triggered:", e.message)

        setIsGettingLocation(false)
        handleGeolocationError(e)
      })

      // Add a test marker to verify markers are working
      const testMarker = L.marker([initialCenter.lat, initialCenter.lng]).addTo(map)
      testMarker.bindPopup("Test marker - If you can see this, markers are working!").openPopup()
      console.log("Test marker added")

      // Trigger a resize event after the map is initialized
      setTimeout(() => {
        if (map && isMounted.current) {
          map.invalidateSize()
          console.log("Map resized")
        }
      }, 100)

      return () => {
        if (map) {
          map.remove()
        }
        mapRef.current = null
        markersRef.current = {}
        locateControlRef.current = null
      }
    } catch (err) {
      console.error("Error initializing map:", err)
      if (isMounted.current) {
        setError(`Error initializing map: ${err.message}. Using fallback map.`)
        setFallbackMode(true)
      }
    }
  }, [isMapLoaded, initialCenter, zoom, isAddingPin])

  // Function to add a pin to the map
  const addPin = () => {
    if (!tempPin) return

    const newPin: Pin = {
      id: Date.now().toString(),
      lat: tempPin.lat,
      lng: tempPin.lng,
      type: newPinType,
      note: newPinNote,
      timestamp: new Date().toISOString(),
    }

    console.log(`Adding new pin: ${JSON.stringify(newPin)}`)
    const updatedPins = [...pins, newPin]
    setPins(updatedPins)

    // Add marker to the map
    if (!fallbackMode && mapRef.current) {
      try {
        const L = (window as any).L

        // Remove any temporary marker first
        if (mapRef.current._tempMarker) {
          mapRef.current.removeLayer(mapRef.current._tempMarker)
          delete mapRef.current._tempMarker
        }

        // Use standard Leaflet markers
        const marker = L.marker([tempPin.lat, tempPin.lng]).addTo(mapRef.current)
        console.log("Marker added to map")

        // Create popup content
        const popupContent = document.createElement("div")
        popupContent.innerHTML = `
          <div>
            <strong>${newPinType === "person" ? "Person" : "Pet"}</strong>
            ${newPinNote ? `<p>${newPinNote}</p>` : ""}
            <p class="text-xs text-gray-500">${new Date().toLocaleString()}</p>
          </div>
        `

        marker.bindPopup(popupContent)
        console.log("Popup bound to marker")

        // Store marker reference
        markersRef.current[newPin.id] = marker

        // Add click handler to select this pin
        marker.on("click", () => {
          setSelectedPin(newPin)
        })
      } catch (err) {
        console.error("Error adding marker:", err)
        setDebugInfo(`Error adding marker: ${err.message}`)
      }
    }

    // Reset temporary state
    setTempPin(null)
    setNewPinNote("")
    setIsAddingPin(false)

    // Notify parent component
    if (onPinsChange) {
      onPinsChange(updatedPins)
    }
  }

  // Function to remove a pin
  const removePin = (id: string) => {
    console.log(`Removing pin: ${id}`)
    // Remove marker from map
    if (!fallbackMode && mapRef.current && markersRef.current[id]) {
      try {
        mapRef.current.removeLayer(markersRef.current[id])
        delete markersRef.current[id]
        console.log("Marker removed from map")
      } catch (err) {
        console.error("Error removing marker:", err)
      }
    }

    // Update pins state
    const updatedPins = pins.filter((pin) => pin.id !== id)
    setPins(updatedPins)

    // Reset selected pin if it was removed
    if (selectedPin && selectedPin.id === id) {
      setSelectedPin(null)
    }

    // Notify parent component
    if (onPinsChange) {
      onPinsChange(updatedPins)
    }
  }

  // Enhanced geocoding function with fuzzy matching
  const geocodeLocation = (query: string) => {
    // Clean up the query
    const cleanQuery = query.toLowerCase().trim()

    // Direct match
    if (GEOCODING_DB[cleanQuery]) {
      return {
        coords: GEOCODING_DB[cleanQuery],
        name: cleanQuery,
      }
    }

    // Check for partial matches
    for (const [key, coords] of Object.entries(GEOCODING_DB)) {
      // Check if the query is contained in the key or vice versa
      if (key.includes(cleanQuery) || cleanQuery.includes(key)) {
        return {
          coords,
          name: key,
        }
      }
    }

    // Check for word matches (for multi-word queries)
    const queryWords = cleanQuery.split(/\s+/)
    if (queryWords.length > 1) {
      // Try to match each word
      for (const [key, coords] of Object.entries(GEOCODING_DB)) {
        const keyWords = key.split(/\s+/)

        // Count how many words match
        let matchCount = 0
        for (const queryWord of queryWords) {
          if (queryWord.length < 3) continue // Skip very short words

          for (const keyWord of keyWords) {
            if (keyWord.includes(queryWord) || queryWord.includes(keyWord)) {
              matchCount++
              break
            }
          }
        }

        // If more than half of the words match, consider it a match
        if (matchCount >= Math.ceil(queryWords.length / 2)) {
          return {
            coords,
            name: key,
          }
        }
      }
    }

    // If we still can't find a match, try to find any partial word match
    for (const [key, coords] of Object.entries(GEOCODING_DB)) {
      for (const queryWord of queryWords) {
        if (queryWord.length < 3) continue // Skip very short words

        if (key.includes(queryWord)) {
          return {
            coords,
            name: key,
          }
        }
      }
    }

    // If we still can't find a match, return null
    return null
  }

  // Handle search - works for both real and fallback maps
  const handleSearch = () => {
    setSearchError(null)

    if (!searchValue.trim()) return

    // Try to geocode the location
    const result = geocodeLocation(searchValue)

    if (result) {
      const { coords, name } = result
      console.log(`Location found: ${name} at ${coords.lat}, ${coords.lng}`)

      if (!fallbackMode && mapRef.current) {
        try {
          const map = mapRef.current

          // IMPORTANT: Set the view AFTER creating the marker to ensure proper centering
          // Use setView instead of flyTo for more reliable positioning
          map.setView([coords.lat, coords.lng], 15, {
            animate: true,
          })
          console.log("Map view updated")

          // Force a map redraw to ensure everything is displayed correctly
          setTimeout(() => {
            if (map && isMounted.current) {
              map.invalidateSize()
            }
          }, 100)

          return
        } catch (err) {
          console.error("Error during map search:", err)
        }
      } else if (fallbackMode && fallbackMapRef.current) {
        // For the fallback map, we'll simulate the location by placing a marker
        // in the center of the map
        return
      }
    }

    // If we get here, the location wasn't found
    console.log(`Location not found: ${searchValue}`)
    setSearchError(`Location "${searchValue}" not found. Try a different search term.`)
    setTimeout(() => {
      if (isMounted.current) {
        setSearchError(null)
      }
    }, 4000)
  }

  // Handle geolocation errors with better user feedback
  const handleGeolocationError = (error: GeolocationPositionError | any) => {
    let errorMessage = "Unable to get your location. Please try searching for a location instead."
    let errorType: "permission" | "timeout" | "position" | "other" = "other"

    console.error("Geolocation error:", error)

    if (typeof error === "object" && error.code) {
      switch (error.code) {
        case 1: // PERMISSION_DENIED
          errorMessage =
            "Location access was denied. You can search for a location or click directly on the map instead."
          errorType = "permission"
          break
        case 2: // POSITION_UNAVAILABLE
          errorMessage = "Your current location is unavailable. Please try searching for a location instead."
          errorType = "position"
          break
        case 3: // TIMEOUT
          errorMessage = "Location request timed out. Please try searching for a location instead."
          errorType = "timeout"
          break
      }
    } else if (typeof error === "string") {
      errorMessage = error
    } else if (error && error.message) {
      errorMessage = error.message
    }

    console.error(`Geolocation error: ${errorMessage}`)

    // Show error message with guidance
    setSearchError(errorMessage)

    // For permission errors, provide a longer message with more help
    if (errorType === "permission") {
      setTimeout(() => {
        if (isMounted.current) {
          setSearchError(
            "To use location: 1) Check browser settings 2) Allow location permissions 3) Refresh the page. Or simply search for a location.",
          )
        }
      }, 4000)

      // Clear after reasonable time
      setTimeout(() => {
        if (isMounted.current) {
          setSearchError(null)
        }
      }, 10000)
    } else {
      // For other errors, clear after shorter time
      setTimeout(() => {
        if (isMounted.current) {
          setSearchError(null)
        }
      }, 6000)
    }
  }

  // Handle successful location retrieval
  const handleLocationFound = (latitude: number, longitude: number) => {
    console.log(`Location found: ${latitude}, ${longitude}`)

    // Show success message
    setSearchError("Location found successfully!")
    setTimeout(() => {
      if (isMounted.current) {
        setSearchError(null)
      }
    }, 2000)

    if (!fallbackMode && mapRef.current) {
      try {
        const map = mapRef.current
        const L = (window as any).L

        // Animate to the current location
        map.flyTo([latitude, longitude], 15, {
          animate: true,
          duration: 1.5,
        })
        console.log("Map view updated to current location")

        // Create a custom icon for the location marker
        const locationIcon = L.icon({
          iconUrl:
            "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IndoaXRlIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgY2xhc3M9Imx1Y2lkZSBsdWNpZGUtbWFwLXBpbiI+PHBhdGggZmlsbD0iIzYwYTVmYSIgZD0iTTIwIDEwYzAgNC40Mi04IDggLTggOHMtOC0zLjU4LTgtOGE4IDggMCAxIDEgMTYgMHoiPjwvcGF0aD48Y2lyY2xlIGN4PSIxMiIgY3k9IjEwIiByPSIzIiBmaWxsPSJ3aGl0ZSI+PC9jaXJjbGU+PC9zdmc+",
          iconSize: [32, 32],
          iconAnchor: [16, 32],
          popupAnchor: [0, -32],
        })

        // Add a marker for the current location
        const locationMarker = L.marker([latitude, longitude], { icon: locationIcon }).addTo(map)
        locationMarker.bindPopup(`Your current location (${latitude.toFixed(6)}, ${longitude.toFixed(6)})`).openPopup()

        // Add a circle to show accuracy
        const accuracyCircle = L.circle([latitude, longitude], {
          radius: 100, // Default radius in meters
          fillColor: "#60a5fa",
          fillOpacity: 0.15,
          color: "#60a5fa",
          weight: 2,
        }).addTo(map)
      } catch (err) {
        console.error("Error displaying location:", err)
        handleGeolocationError("Error displaying your location. Please try again.")
      }
    }
  }

  // Handle getting current location
  const getCurrentLocation = () => {
    // Clear any existing errors
    setSearchError(null)
    setIsGettingLocation(true)

    // Check if geolocation is available
    if (!navigator.geolocation) {
      setIsGettingLocation(false)
      setSearchError("Geolocation is not supported by your browser. Please search for a location instead.")
      return
    }

    // Show loading indicator with more descriptive message
    setSearchError("Requesting your location... Check your browser permissions if prompted.")
    console.log("Requesting geolocation manually")

    // Try to use the map's locate method first if available
    if (!fallbackMode && mapRef.current) {
      try {
        console.log("Using map.locate() method")
        mapRef.current.locate({
          setView: true,
          maxZoom: 16,
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0,
        })
        return
      } catch (err) {
        console.error("Error using map.locate():", err)
        // Fall back to the browser's geolocation API
      }
    }

    // Add an alternative message after a short delay to help users understand what might be happening
    const permissionTimeoutId = setTimeout(() => {
      if (isMounted.current && isGettingLocation) {
        setSearchError(
          "Waiting for location permission. Please allow location access when prompted or use the search instead.",
        )
      }
    }, 3000)

    // Use the browser's geolocation API as a fallback
    navigator.geolocation.getCurrentPosition(
      (position) => {
        if (!isMounted.current) return
        clearTimeout(permissionTimeoutId)
        setIsGettingLocation(false)

        const { latitude, longitude } = position.coords
        handleLocationFound(latitude, longitude)
      },
      (err) => {
        clearTimeout(permissionTimeoutId)
        setIsGettingLocation(false)
        handleGeolocationError(err)
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      },
    )
  }

  // Cancel adding a pin
  const cancelAddPin = () => {
    setIsAddingPin(false)
    setTempPin(null)
    setNewPinNote("")
  }

  // Render custom marker for fallback mode
  const renderFallbackMarker = (type: "person" | "pet", x: number, y: number) => {
    const color = type === "person" ? "#f87c96" : "#60a5fa"
    return (
      <div
        className="absolute pointer-events-none"
        style={{
          left: `${x}px`,
          top: `${y}px`,
          transform: "translate(-50%, -100%)",
        }}
      >
        <div className="relative">
          <div className="w-10 h-12 rounded-full relative" style={{ backgroundColor: color }}>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                {type === "person" ? (
                  <User className="h-4 w-4" style={{ color }} />
                ) : (
                  <PawPrint className="h-4 w-4" style={{ color }} />
                )}
              </div>
            </div>
            <div
              className="absolute bottom-0 left-1/2 w-4 h-4 transform rotate-45 -translate-x-1/2 translate-y-1/2"
              style={{ backgroundColor: color }}
            ></div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            placeholder="Search for a location (e.g., UC Davis, New York, etc.)"
            className="pr-10"
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          />
          {searchValue && (
            <button
              className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              onClick={() => setSearchValue("")}
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <Button variant="outline" size="icon" onClick={handleSearch} title="Search location">
          <Search className="h-4 w-4" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={getCurrentLocation}
          className="relative group"
          disabled={isGettingLocation}
          title="Use your current location (requires permission)"
        >
          {isGettingLocation ? (
            <div className="h-4 w-4 animate-spin rounded-full border-2 border-gray-300 border-t-blue-600"></div>
          ) : (
            <Locate className="h-4 w-4" />
          )}
          <span className="absolute -top-10 left-1/2 transform -translate-x-1/2 bg-black text-white text-xs rounded px-2 py-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap">
            Use my location
          </span>
        </Button>
      </div>

      {searchError && (
        <Alert
          variant={
            searchError.includes("successfully")
              ? "success"
              : searchError.includes("Requesting")
                ? "default"
                : "warning"
          }
          className="py-2"
        >
          <AlertDescription className="text-xs flex items-center">
            {searchError.includes("denied") && <MapPin className="h-4 w-4 mr-1 flex-shrink-0" />}
            {searchError}
          </AlertDescription>
        </Alert>
      )}

      {/* Add a brief help text to guide users on alternatives */}
      <div className="text-xs text-gray-500 -mt-1">
        <span className="flex items-center">
          <MapPin className="h-3 w-3 mr-1 inline-block text-gray-400" />
          Tip: You can search for a location, use current location, or click directly on the map
        </span>
      </div>

      {/* Add a more prominent Add Marker button */}
      <Button
        variant={isAddingPin ? "default" : "outline"}
        onClick={() => setIsAddingPin(!isAddingPin)}
        className={`w-full mt-2 ${isAddingPin ? "bg-blue-500 hover:bg-blue-600 text-white" : ""}`}
      >
        {isAddingPin ? (
          <>
            <X className="h-4 w-4 mr-2" /> Cancel Adding Marker
          </>
        ) : (
          <>
            <Plus className="h-4 w-4 mr-2" /> Add a Marker
          </>
        )}
      </Button>

      {debugInfo && (
        <Alert variant="info" className="py-2 bg-yellow-50 border-yellow-200 text-yellow-800">
          <AlertDescription className="text-xs">{debugInfo}</AlertDescription>
        </Alert>
      )}

      {isAddingPin && (
        <Alert variant="info" className="py-3 bg-blue-50 border-blue-200 text-blue-800 mt-2">
          <div className="flex items-center">
            <MapPin className="h-5 w-5 mr-2 text-blue-500" />
            <AlertDescription className="text-sm font-medium">
              Click anywhere on the map to place a marker
            </AlertDescription>
          </div>
        </Alert>
      )}

      <div style={{ height, width: "100%" }} className="relative rounded-md overflow-hidden border border-gray-200">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-50 z-10">
            <div className="flex flex-col items-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mb-2"></div>
              <p className="text-sm text-gray-600">Loading map...</p>
            </div>
          </div>
        )}

        {error && (
          <div className="absolute inset-0 flex items-center justify-center bg-red-50 p-4 z-10">
            <div className="text-red-500 text-center">
              <p className="font-medium">{error}</p>
              <p className="text-sm mt-2">Please try refreshing the page</p>
            </div>
          </div>
        )}

        <div ref={mapContainerRef} className="h-full w-full"></div>

        {/* Fallback map if Leaflet fails to load */}
        {fallbackMode && (
          <div ref={fallbackMapRef} className="absolute inset-0 bg-blue-50 cursor-pointer">
            <div className="absolute inset-0 grid grid-cols-8 grid-rows-8">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={`row-${i}`} className="border-t border-gray-200" />
              ))}
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={`col-${i}`} className="border-l border-gray-200" />
              ))}
            </div>

            {/* Simulated map features */}
            <div className="absolute inset-0">
              <div className="absolute top-1/4 left-0 right-0 h-1 bg-gray-300"></div>
              <div className="absolute top-3/4 left-0 right-0 h-1 bg-gray-300"></div>
              <div className="absolute left-1/4 top-0 bottom-0 w-1 bg-gray-300"></div>
              <div className="absolute left-3/4 top-0 bottom-0 w-1 bg-gray-300"></div>
              <div className="absolute top-1/2 left-1/2 w-16 h-16 bg-blue-200 rounded-full transform -translate-x-1/2 -translate-y-1/2"></div>
            </div>

            {/* Render fallback markers */}
            {pins.map((pin) => (
              <div key={pin.id}>
                {renderFallbackMarker(
                  pin.type,
                  fallbackMapRef.current ? fallbackMapRef.current.clientWidth / 2 : 0,
                  fallbackMapRef.current ? fallbackMapRef.current.clientHeight / 2 : 0,
                )}
              </div>
            ))}

            {!isAddingPin && !searchValue && pins.length === 0 && (
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
                <MapPin className="h-8 w-8 text-gray-500 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Search for a location or add markers to mark sightings</p>
              </div>
            )}
          </div>
        )}

        {/* Pin adding UI */}
        {tempPin && (
          <div id="pin-form" className="mt-3 bg-white p-4 rounded-lg shadow-sm border border-gray-200">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <h3 className="font-medium text-blue-700">Add New Marker</h3>
                <Button variant="ghost" size="sm" onClick={cancelAddPin} className="h-7 w-7 p-0">
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">Marker Type</Label>
                <RadioGroup
                  value={newPinType}
                  onValueChange={(value) => setNewPinType(value as "person" | "pet")}
                  className="flex gap-4"
                >
                  <div className="flex items-center space-x-1">
                    <RadioGroupItem value="person" id="pin-type-person" />
                    <Label htmlFor="pin-type-person" className="text-sm flex items-center">
                      <User className="h-3 w-3 mr-1" /> Person
                    </Label>
                  </div>
                  <div className="flex items-center space-x-1">
                    <RadioGroupItem value="pet" id="pin-type-pet" />
                    <Label htmlFor="pin-type-pet" className="text-sm flex items-center">
                      <PawPrint className="h-3 w-3 mr-1" /> Pet
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label htmlFor="pin-note" className="text-sm font-medium">
                  Note (optional)
                </Label>
                <Textarea
                  id="pin-note"
                  placeholder="Add details about this sighting"
                  value={newPinNote}
                  onChange={(e) => setNewPinNote(e.target.value)}
                  rows={2}
                  className="resize-none"
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={cancelAddPin}>
                  Cancel
                </Button>
                <Button onClick={addPin} className="bg-blue-500 hover:bg-blue-600">
                  Add Marker
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Pins list */}
      {pins.length > 0 && (
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-medium">Markers ({pins.length})</h3>
            {pins.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                className="h-8 text-red-500 hover:text-red-700 hover:bg-red-50"
                onClick={() => {
                  // Clear all pins
                  pins.forEach((pin) => removePin(pin.id))
                }}
              >
                <Trash className="h-4 w-4 mr-1" />
                Clear All
              </Button>
            )}
          </div>

          <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
            {pins.map((pin) => (
              <div
                key={pin.id}
                className={`flex items-start justify-between p-2 rounded-md border ${
                  selectedPin?.id === pin.id ? "bg-blue-50 border-blue-200" : "bg-gray-50 border-gray-200"
                }`}
              >
                <div className="flex items-start gap-2">
                  {pin.type === "person" ? (
                    <div className="w-5 h-5 rounded-full bg-[#f87c96] flex items-center justify-center">
                      <User className="h-3 w-3 text-white" />
                    </div>
                  ) : (
                    <div className="w-5 h-5 rounded-full bg-[#60a5fa] flex items-center justify-center">
                      <PawPrint className="h-3 w-3 text-white" />
                    </div>
                  )}
                  <div>
                    <div className="flex items-center gap-1">
                      <p className="text-sm font-medium">{pin.type === "person" ? "Person" : "Pet"}</p>
                      <Badge variant="outline" className="text-xs px-1 py-0 h-4">
                        {new Date(pin.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </Badge>
                    </div>
                    {pin.note && <p className="text-xs text-gray-600 mt-0.5">{pin.note}</p>}
                    <p className="text-xs text-gray-500 mt-0.5">
                      {pin.lat.toFixed(6)}, {pin.lng.toFixed(6)}
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removePin(pin.id)}
                  className="h-6 w-6 p-0 text-gray-400 hover:text-red-500"
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
