"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { MapPin, X, Search, Locate } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface EnhancedMapProps {
  onPinDrop?: (location: { lat: number; lng: number; address: string }) => void
  initialCenter?: { lat: number; lng: number }
  height?: string
}

export function EnhancedMap({
  onPinDrop,
  initialCenter = { lat: 37.7749, lng: -122.4194 }, // Default to San Francisco
  height = "400px",
}: EnhancedMapProps) {
  const [pinPosition, setPinPosition] = useState<{ x: number; y: number } | null>(null)
  const [address, setAddress] = useState<string | null>(null)
  const [searchValue, setSearchValue] = useState("")
  const mapRef = useRef<HTMLDivElement>(null)
  const [mapSize, setMapSize] = useState({ width: 0, height: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [mapOffset, setMapOffset] = useState({ x: 0, y: 0 })
  const [zoom, setZoom] = useState(1)
  const dragStartRef = useRef<{ x: number; y: number } | null>(null)
  const offsetStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 })

  // Update map size on resize
  useEffect(() => {
    const updateMapSize = () => {
      if (mapRef.current) {
        setMapSize({
          width: mapRef.current.clientWidth,
          height: mapRef.current.clientHeight,
        })
      }
    }

    updateMapSize()
    window.addEventListener("resize", updateMapSize)
    return () => window.removeEventListener("resize", updateMapSize)
  }, [])

  // Generate a simulated lat/lng based on the pin position
  const getSimulatedCoordinates = (x: number, y: number) => {
    if (!mapRef.current) return { lat: 0, lng: 0 }

    const width = mapRef.current.clientWidth
    const height = mapRef.current.clientHeight

    // Adjust for map offset and zoom
    const adjustedX = (x - mapOffset.x) / zoom
    const adjustedY = (y - mapOffset.y) / zoom

    // Convert pixel position to a simulated lat/lng
    const lat = initialCenter.lat + ((height / 2 - adjustedY) / height) * 0.1 * zoom
    const lng = initialCenter.lng + ((adjustedX - width / 2) / width) * 0.1 * zoom

    return { lat: Number.parseFloat(lat.toFixed(6)), lng: Number.parseFloat(lng.toFixed(6)) }
  }

  const handleMapClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!mapRef.current || isDragging) return

    const rect = mapRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top
    setPinPosition({ x, y })

    // Generate a simulated address based on the coordinates
    const coords = getSimulatedCoordinates(x, y)
    const simulatedAddress = `Location at ${coords.lat.toFixed(6)}, ${coords.lng.toFixed(6)}`
    setAddress(simulatedAddress)

    // Call the callback with the simulated location data
    if (onPinDrop) {
      onPinDrop({
        lat: coords.lat,
        lng: coords.lng,
        address: simulatedAddress,
      })
    }
  }

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    dragStartRef.current = { x: e.clientX, y: e.clientY }
    offsetStartRef.current = { ...mapOffset }
    setIsDragging(true)
  }

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDragging || !dragStartRef.current) return

    const dx = e.clientX - dragStartRef.current.x
    const dy = e.clientY - dragStartRef.current.y

    setMapOffset({
      x: offsetStartRef.current.x + dx,
      y: offsetStartRef.current.y + dy,
    })
  }

  const handleMouseUp = () => {
    setIsDragging(false)
    dragStartRef.current = null
  }

  const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    e.preventDefault()
    const delta = e.deltaY * -0.01
    const newZoom = Math.min(Math.max(0.5, zoom + delta), 2)
    setZoom(newZoom)
  }

  const clearPin = () => {
    setPinPosition(null)
    setAddress(null)

    // Call the callback with empty data
    if (onPinDrop) {
      onPinDrop({ lat: 0, lng: 0, address: "" })
    }
  }

  const handleSearch = () => {
    if (!searchValue.trim()) return

    // Simulate a search by placing the pin in the center
    if (mapRef.current) {
      const width = mapRef.current.clientWidth
      const height = mapRef.current.clientHeight
      const x = width / 2
      const y = height / 2

      setPinPosition({ x, y })

      // Generate a simulated address that includes the search term
      const coords = getSimulatedCoordinates(x, y)
      const simulatedAddress = `${searchValue} (${coords.lat.toFixed(6)}, ${coords.lng.toFixed(6)})`
      setAddress(simulatedAddress)

      // Call the callback with the simulated location data
      if (onPinDrop) {
        onPinDrop({
          lat: coords.lat,
          lng: coords.lng,
          address: simulatedAddress,
        })
      }
    }
  }

  const getCurrentLocation = () => {
    // Simulate getting current location by placing the pin slightly off-center
    if (mapRef.current) {
      const width = mapRef.current.clientWidth
      const height = mapRef.current.clientHeight
      const x = width / 2 + (Math.random() * 50 - 25)
      const y = height / 2 + (Math.random() * 50 - 25)

      setPinPosition({ x, y })

      // Generate a simulated address for the "current location"
      const coords = getSimulatedCoordinates(x, y)
      const simulatedAddress = `Your current location (${coords.lat.toFixed(6)}, ${coords.lng.toFixed(6)})`
      setAddress(simulatedAddress)

      // Call the callback with the simulated location data
      if (onPinDrop) {
        onPinDrop({
          lat: coords.lat,
          lng: coords.lng,
          address: simulatedAddress,
        })
      }
    }
  }

  const resetView = () => {
    setMapOffset({ x: 0, y: 0 })
    setZoom(1)
  }

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            placeholder="Search for a location"
            className="pr-10"
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          />
          {searchValue && (
            <button
              className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              onClick={() => setSearchValue("")}
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <Button variant="outline" size="icon" onClick={handleSearch} title="Search location">
          <Search className="h-4 w-4" />
        </Button>
        <Button variant="outline" size="icon" onClick={getCurrentLocation} title="Use current location">
          <Locate className="h-4 w-4" />
        </Button>
      </div>

      <div
        ref={mapRef}
        className="relative rounded-md overflow-hidden border border-gray-200 cursor-grab active:cursor-grabbing"
        style={{ height }}
        onClick={handleMapClick}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
      >
        {/* Enhanced map visualization */}
        <div
          className="absolute inset-0 bg-blue-50"
          style={{
            transform: `translate(${mapOffset.x}px, ${mapOffset.y}px) scale(${zoom})`,
            transformOrigin: "center",
            transition: isDragging ? "none" : "transform 0.1s ease-out",
          }}
        >
          {/* Grid pattern */}
          <div className="absolute inset-0 grid grid-cols-12 grid-rows-12">
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={`row-${i}`} className="border-t border-gray-200" />
            ))}
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={`col-${i}`} className="border-l border-gray-200" />
            ))}
          </div>

          {/* Main roads */}
          <div className="absolute inset-0">
            <div className="absolute top-1/4 left-0 right-0 h-1 bg-gray-300" />
            <div className="absolute top-3/4 left-0 right-0 h-1 bg-gray-300" />
            <div className="absolute left-1/4 top-0 bottom-0 w-1 bg-gray-300" />
            <div className="absolute left-3/4 top-0 bottom-0 w-1 bg-gray-300" />

            {/* Diagonal roads */}
            <div
              className="absolute h-0.5 bg-gray-300"
              style={{
                top: "0",
                left: "0",
                width: "141.4%",
                transformOrigin: "top left",
                transform: "rotate(45deg)",
              }}
            />
            <div
              className="absolute h-0.5 bg-gray-300"
              style={{
                top: "0",
                right: "0",
                width: "141.4%",
                transformOrigin: "top right",
                transform: "rotate(-45deg)",
              }}
            />
          </div>

          {/* City blocks */}
          <div className="absolute top-1/8 left-1/8 w-1/4 h-1/4 bg-gray-100 rounded-sm" />
          <div className="absolute top-1/8 right-1/8 w-1/4 h-1/4 bg-gray-100 rounded-sm" />
          <div className="absolute bottom-1/8 left-1/8 w-1/4 h-1/4 bg-gray-100 rounded-sm" />
          <div className="absolute bottom-1/8 right-1/8 w-1/4 h-1/4 bg-gray-100 rounded-sm" />

          {/* Water feature */}
          <div className="absolute top-1/2 left-1/2 w-1/5 h-1/5 bg-blue-200 rounded-full transform -translate-x-1/2 -translate-y-1/2" />

          {/* Parks */}
          <div className="absolute top-1/4 left-1/2 w-1/6 h-1/6 bg-green-200 rounded-sm transform -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute top-3/4 left-1/2 w-1/6 h-1/6 bg-green-200 rounded-sm transform -translate-x-1/2 -translate-y-1/2" />
        </div>

        {/* Pin marker */}
        {pinPosition && (
          <div
            className="absolute pointer-events-none"
            style={{
              left: `${pinPosition.x}px`,
              top: `${pinPosition.y}px`,
              transform: "translate(-50%, -100%)",
            }}
          >
            <div className="relative">
              <MapPin className="h-8 w-8 text-red-500 drop-shadow-md" />
              <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2 w-4 h-4 bg-white rounded-full border-2 border-red-500 shadow-md"></div>
            </div>
          </div>
        )}

        {/* Map controls */}
        <div className="absolute top-2 right-2 flex flex-col gap-1">
          <Button
            variant="secondary"
            size="icon"
            className="h-8 w-8 bg-white shadow-md"
            onClick={() => setZoom(Math.min(zoom + 0.2, 2))}
          >
            <span className="text-lg font-bold">+</span>
          </Button>
          <Button
            variant="secondary"
            size="icon"
            className="h-8 w-8 bg-white shadow-md"
            onClick={() => setZoom(Math.max(zoom - 0.2, 0.5))}
          >
            <span className="text-lg font-bold">-</span>
          </Button>
          <Button
            variant="secondary"
            size="icon"
            className="h-8 w-8 bg-white shadow-md"
            onClick={resetView}
            title="Reset view"
          >
            <Locate className="h-4 w-4" />
          </Button>
        </div>

        {/* Instructions overlay */}
        {!pinPosition && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4 bg-black/5 pointer-events-none">
            <MapPin className="h-8 w-8 text-gray-500 mb-2" />
            <p className="text-sm text-gray-600">Tap to drop a pin, drag to move the map</p>
            <p className="text-xs text-gray-500 mt-1">Use mouse wheel or buttons to zoom</p>
          </div>
        )}
      </div>

      {address && (
        <div className="flex items-center justify-between bg-gray-50 p-3 rounded-md border border-gray-200">
          <div className="flex items-start gap-2">
            <MapPin className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium">Dropped Pin</p>
              <p className="text-xs text-gray-500">{address}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={clearPin} className="h-8 text-gray-500 hover:text-gray-700">
            <X className="h-4 w-4 mr-1" />
            Clear
          </Button>
        </div>
      )}
    </div>
  )
}
