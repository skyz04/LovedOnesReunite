import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Heart, Search, MapPin, User } from "lucide-react"
import { MeshGradientBackground } from "@/components/mesh-gradient-background"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen bg-[#fcfcfd]">
      <header className="relative z-10 border-b border-[#f0f0f5] px-4 py-4">
        <div className="flex items-center justify-center">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-[#f87c96]" />
            <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-[#f87c96] to-[#c084fc]">
              FindKind
            </span>
          </div>
        </div>
      </header>

      <main className="flex-1">
        <section className="relative overflow-hidden">
          <div className="absolute inset-0">
            <MeshGradientBackground colors={["#f9a8d4", "#ddd6fe", "#bfdbfe", "#a7f3d0"]} speed={0.001} />
          </div>
          <div className="relative z-10 px-4 py-8 md:py-12">
            <div className="text-center mb-8">
              <h1 className="text-2xl font-bold tracking-tight mb-2 bg-clip-text text-transparent bg-gradient-to-r from-[#f87c96] to-[#c084fc]">
                Help Find Missing Loved Ones
              </h1>
              <p className="text-[#6b7280] text-sm">
                Connect those who've lost someone with those who might have seen them
              </p>
            </div>
          </div>
        </section>

        <section className="px-4 py-6 -mt-4">
          <div className="space-y-4">
            <Link href="/report-missing" className="block">
              <Button className="w-full h-24 flex flex-col items-center justify-center gap-2 bg-gradient-to-r from-[#f87c96] to-[#c084fc] hover:opacity-90 shadow-lg shadow-pink-500/20 rounded-2xl text-white">
                <User className="h-8 w-8" />
                <span className="text-lg font-medium">Report Missing</span>
              </Button>
            </Link>

            <Link href="/search-match" className="block">
              <Button
                className="w-full h-24 flex flex-col items-center justify-center gap-2 bg-white border border-[#e5e7eb] hover:bg-[#f9fafb] shadow-md rounded-2xl text-[#374151]"
                variant="outline"
              >
                <Search className="h-8 w-8 text-[#60a5fa]" />
                <span className="text-lg font-medium">Search & Match</span>
              </Button>
            </Link>

            <Link href="/drop-pin" className="block">
              <Button
                className="w-full h-24 flex flex-col items-center justify-center gap-2 bg-white border border-[#e5e7eb] hover:bg-[#f9fafb] shadow-md rounded-2xl text-[#374151]"
                variant="outline"
              >
                <MapPin className="h-8 w-8 text-[#34d399]" />
                <span className="text-lg font-medium">Drop Pin on Map</span>
              </Button>
            </Link>
          </div>
        </section>

        <section className="px-4 py-8">
          <div className="bg-white rounded-2xl p-6 shadow-md border border-[#f0f0f5]">
            <h2 className="text-lg font-bold text-[#374151] mb-3">How It Works</h2>
            <ul className="space-y-3 text-sm text-[#6b7280]">
              <li className="flex items-start gap-2">
                <div className="w-6 h-6 rounded-full bg-[#fce7f3] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-[#f87c96] font-bold text-xs">1</span>
                </div>
                <span>Report a missing person with photos and details</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-6 h-6 rounded-full bg-[#dbeafe] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-[#60a5fa] font-bold text-xs">2</span>
                </div>
                <span>Search the database with photos or details to find matches</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-6 h-6 rounded-full bg-[#d1fae5] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-[#34d399] font-bold text-xs">3</span>
                </div>
                <span>Drop pins on the map where someone was last seen</span>
              </li>
            </ul>
          </div>
        </section>
      </main>

      <footer className="border-t border-[#f0f0f5] py-4 px-4 bg-[#fcfcfd] text-center">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Heart className="h-4 w-4 text-[#f87c96]" />
          <span className="text-sm font-bold bg-clip-text text-transparent bg-gradient-to-r from-[#f87c96] to-[#c084fc]">
            FindKind
          </span>
        </div>
        <p className="text-xs text-[#6b7280]">© {new Date().getFullYear()} FindKind. All rights reserved.</p>
      </footer>
    </div>
  )
}
