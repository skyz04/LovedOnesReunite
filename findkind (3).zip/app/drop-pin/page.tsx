"use client"

import Link from "next/link"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { ArrowLeft, MapPin, Calendar, User, PawPrint } from "lucide-react"
import { DatePicker } from "@/components/date-picker"
import { MeshGradientBackground } from "@/components/mesh-gradient-background"
import { SimpleMapPinDropper } from "@/components/simple-map-pin-dropper"

export default function DropPinPage() {
  const [locationData, setLocationData] = useState<{ lat: number; lng: number; address: string } | null>(null)

  return (
    <div className="relative min-h-screen bg-[#fcfcfd]">
      <div className="absolute inset-0 opacity-20">
        <MeshGradientBackground colors={["#d1fae5", "#bfdbfe", "#ddd6fe", "#f9a8d4"]} speed={0.001} />
      </div>
      <div className="px-4 py-6 relative z-10">
        <Link href="/" className="inline-flex items-center text-sm font-medium mb-4 hover:underline text-[#6b7280]">
          <ArrowLeft className="mr-1 h-4 w-4" />
          Back
        </Link>

        <div className="mb-6">
          <h1 className="text-2xl font-bold tracking-tight mb-2 bg-clip-text text-transparent bg-gradient-to-r from-[#34d399] to-[#10b981]">
            Drop Pin on Map
          </h1>
          <p className="text-[#6b7280] text-sm">Mark a location where you saw someone who might be missing</p>
        </div>

        <Card className="bg-white/80 backdrop-blur-sm border-[#f0f0f5]">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg text-[#374151]">Sighting Location</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="flex items-center gap-1">
                <MapPin className="h-4 w-4" />
                Drop Pin on Map
              </Label>
              <div className="rounded-md overflow-hidden">
                <SimpleMapPinDropper
                  height="300px"
                  onPinDrop={(location) => {
                    console.log("Pin dropped at:", location)
                    setLocationData(location)
                  }}
                />
              </div>
              <p className="text-xs text-amber-600 mt-1">
                Using simplified map interface. For full Google Maps functionality, please ensure your API key is
                properly configured.
              </p>
            </div>

            <div className="space-y-2">
              <Label>Sighting Type</Label>
              <RadioGroup defaultValue="person" className="flex gap-4">
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="person" id="pin-person" />
                  <Label htmlFor="pin-person" className="text-sm flex items-center">
                    <User className="h-3 w-3 mr-1" /> Person
                  </Label>
                </div>
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="pet" id="pin-pet" />
                  <Label htmlFor="pin-pet" className="text-sm flex items-center">
                    <PawPrint className="h-3 w-3 mr-1" /> Pet
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                Date & Time Seen
              </Label>
              <div className="grid grid-cols-2 gap-3">
                <DatePicker />
                <Input type="time" className="border-[#e5e7eb] focus-visible:ring-[#34d399]" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Brief Description</Label>
              <Textarea
                id="description"
                placeholder="Describe who you saw (appearance, clothing, behavior, etc.)"
                rows={3}
                className="border-[#e5e7eb] focus-visible:ring-[#34d399]"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contact">Your Contact Information (Optional)</Label>
              <Input
                id="contact-phone"
                placeholder="Phone number"
                type="tel"
                className="border-[#e5e7eb] focus-visible:ring-[#34d399]"
              />
            </div>
          </CardContent>
          <CardFooter className="flex flex-col space-y-2">
            <Button
              className="w-full bg-gradient-to-r from-[#34d399] to-[#10b981] hover:opacity-90"
              disabled={!locationData}
            >
              <MapPin className="mr-2 h-4 w-4" />
              Submit Pin
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
