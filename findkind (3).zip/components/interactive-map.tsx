"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MapPin, Locate, Search, X } from "lucide-react"

// Define types for Google Maps objects
type GoogleMap = google.maps.Map
type GoogleMarker = google.maps.Marker
type LatLngLiteral = google.maps.LatLngLiteral
type MapOptions = google.maps.MapOptions

interface InteractiveMapProps {
  onPinDrop?: (location: { lat: number; lng: number; address: string }) => void
  initialCenter?: LatLngLiteral
  height?: string
}

// Declare google as a global variable
declare global {
  interface Window {
    google: any
  }
}

export function InteractiveMap({
  onPinDrop,
  initialCenter = { lat: 37.7749, lng: -122.4194 }, // Default to San Francisco
  height = "400px",
}: InteractiveMapProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const [map, setMap] = useState<GoogleMap | null>(null)
  const [marker, setMarker] = useState<GoogleMarker | null>(null)
  const [searchValue, setSearchValue] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [address, setAddress] = useState<string>("")

  // Initialize the map
  useEffect(() => {
    // Check if the Google Maps script is already loaded
    if (!window.google) {
      setError("Google Maps failed to load. Please refresh the page.")
      setIsLoading(false)
      return
    }

    if (mapRef.current && !map) {
      const mapOptions: MapOptions = {
        center: initialCenter,
        zoom: 13,
        mapTypeControl: false,
        fullscreenControl: false,
        streetViewControl: false,
        zoomControl: true,
        zoomControlOptions: {
          position: google.maps.ControlPosition.RIGHT_TOP,
        },
        gestureHandling: "greedy", // Better for mobile
        styles: [
          {
            featureType: "poi",
            elementType: "labels",
            stylers: [{ visibility: "off" }],
          },
        ],
      }

      const newMap = new google.maps.Map(mapRef.current, mapOptions)
      setMap(newMap)
      setIsLoading(false)

      // Add click listener to the map
      newMap.addListener("click", (e: google.maps.MapMouseEvent) => {
        if (e.latLng) {
          placeMarker(e.latLng)
        }
      })
    }
  }, [initialCenter, map])

  // Function to place a marker on the map
  const placeMarker = useCallback(
    async (latLng: google.maps.LatLng) => {
      if (!map) return

      // Remove existing marker if any
      if (marker) {
        marker.setMap(null)
      }

      // Create a new marker
      const newMarker = new google.maps.Marker({
        position: latLng,
        map: map,
        animation: google.maps.Animation.DROP,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          fillColor: "#ef4444",
          fillOpacity: 1,
          strokeWeight: 0,
          scale: 10,
        },
      })

      setMarker(newMarker)

      // Get address from coordinates (reverse geocoding)
      try {
        const geocoder = new google.maps.Geocoder()
        const response = await geocoder.geocode({ location: latLng })

        if (response.results[0]) {
          const addressText = response.results[0].formatted_address
          setAddress(addressText)

          // Call the callback with location data
          if (onPinDrop) {
            onPinDrop({
              lat: latLng.lat(),
              lng: latLng.lng(),
              address: addressText,
            })
          }
        }
      } catch (error) {
        console.error("Error getting address:", error)
        setAddress("Unknown location")

        // Still call the callback with coordinates
        if (onPinDrop) {
          onPinDrop({
            lat: latLng.lat(),
            lng: latLng.lng(),
            address: "Unknown location",
          })
        }
      }
    },
    [map, marker, onPinDrop],
  )

  // Function to search for a location
  const searchLocation = useCallback(async () => {
    if (!map || !searchValue.trim()) return

    try {
      const geocoder = new google.maps.Geocoder()
      const response = await geocoder.geocode({ address: searchValue })

      if (response.results[0]?.geometry?.location) {
        const location = response.results[0].geometry.location
        map.setCenter(location)
        placeMarker(location)
      } else {
        setError("Location not found. Please try a different search.")
        setTimeout(() => setError(null), 3000)
      }
    } catch (error) {
      console.error("Error searching location:", error)
      setError("Error searching location. Please try again.")
      setTimeout(() => setError(null), 3000)
    }
  }, [map, searchValue, placeMarker])

  // Function to get current location
  const getCurrentLocation = useCallback(() => {
    if (!map) return

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const currentLocation = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          }

          map.setCenter(currentLocation)
          placeMarker(new google.maps.LatLng(currentLocation.lat, currentLocation.lng))
        },
        () => {
          setError("Unable to get your location. Please check your device settings.")
          setTimeout(() => setError(null), 3000)
        },
      )
    } else {
      setError("Geolocation is not supported by your browser.")
      setTimeout(() => setError(null), 3000)
    }
  }, [map, placeMarker])

  // Clear the marker
  const clearMarker = useCallback(() => {
    if (marker) {
      marker.setMap(null)
      setMarker(null)
      setAddress("")

      if (onPinDrop) {
        onPinDrop({ lat: 0, lng: 0, address: "" })
      }
    }
  }, [marker, onPinDrop])

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            placeholder="Search for a location"
            className="pr-10"
            onKeyDown={(e) => e.key === "Enter" && searchLocation()}
          />
          {searchValue && (
            <button
              className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              onClick={() => setSearchValue("")}
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <Button variant="outline" size="icon" onClick={searchLocation} title="Search location">
          <Search className="h-4 w-4" />
        </Button>
        <Button variant="outline" size="icon" onClick={getCurrentLocation} title="Use current location">
          <Locate className="h-4 w-4" />
        </Button>
      </div>

      <div className="relative rounded-md overflow-hidden border border-gray-200" style={{ height }}>
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
          </div>
        )}

        {error && (
          <div className="absolute top-2 left-2 right-2 z-10 bg-red-100 text-red-800 px-3 py-2 rounded-md text-sm">
            {error}
          </div>
        )}

        <div ref={mapRef} className="h-full w-full" />

        {!isLoading && !map && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-100 p-4 text-center">
            <MapPin className="h-8 w-8 text-gray-400 mb-2" />
            <p className="text-gray-600">Map could not be loaded. Please check your internet connection.</p>
          </div>
        )}
      </div>

      {address && (
        <div className="flex items-center justify-between bg-gray-50 p-3 rounded-md border border-gray-200">
          <div className="flex items-start gap-2">
            <MapPin className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium">Dropped Pin</p>
              <p className="text-xs text-gray-500">{address}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={clearMarker} className="h-8 text-gray-500 hover:text-gray-700">
            <X className="h-4 w-4 mr-1" />
            Clear
          </Button>
        </div>
      )}
    </div>
  )
}
