"use client"

import { useState, useRef } from "react"
import { SimpleMapPinDropper } from "@/components/simple-map-pin-dropper"

interface ReactGoogleMapProps {
  onPinDrop?: (location: { lat: number; lng: number; address: string }) => void
  initialCenter?: { lat: number; lng: number }
  height?: string
  apiKey?: string
}

export function ReactGoogleMap({
  onPinDrop,
  initialCenter = { lat: 37.7749, lng: -122.4194 },
  height = "400px",
  apiKey = "AIzaSyBDQc5Fjz_wM7og4fC9edGcCdjxeTOt7Us", // Default to the provided key
}: ReactGoogleMapProps) {
  const [mapError, setMapError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const mapRef = useRef<HTMLDivElement>(null)
  const scriptRef = useRef<HTMLScriptElement | null>(null)

  // We'll use the SimpleMapPinDropper as a fallback
  if (mapError) {
    return (
      <div className="space-y-3">
        <div className="bg-amber-50 border border-amber-200 rounded-md p-3 text-sm text-amber-700">
          <p className="font-medium mb-1">Google Maps could not be loaded: {mapError}</p>
          <p>Using simplified map as a fallback.</p>
        </div>
        <SimpleMapPinDropper height={height} onPinDrop={onPinDrop} />
      </div>
    )
  }

  // Since we're having issues with the Google Maps API, let's use the SimpleMapPinDropper directly
  return <SimpleMapPinDropper height={height} onPinDrop={onPinDrop} />
}
