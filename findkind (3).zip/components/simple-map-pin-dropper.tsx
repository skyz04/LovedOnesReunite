"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { MapPin, X, Search, Locate } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface SimpleMapPinDropperProps {
  onPinDrop?: (location: { lat: number; lng: number; address: string }) => void
  height?: string
}

export function SimpleMapPinDropper({ onPinDrop, height = "400px" }: SimpleMapPinDropperProps) {
  const [pinPosition, setPinPosition] = useState<{ x: number; y: number } | null>(null)
  const [address, setAddress] = useState<string | null>(null)
  const [searchValue, setSearchValue] = useState("")
  const mapRef = useRef<HTMLDivElement>(null)
  const [mapImage, setMapImage] = useState<string>("/map-background.jpg")

  // Load a random map background on component mount
  useEffect(() => {
    const mapImages = ["/map-background.jpg", "/detailed-city-street-map.png", "/city-intersection.png"]
    setMapImage(mapImages[Math.floor(Math.random() * mapImages.length)])
  }, [])

  // Generate a simulated lat/lng based on the pin position
  const getSimulatedCoordinates = (x: number, y: number) => {
    if (!mapRef.current) return { lat: 0, lng: 0 }

    const width = mapRef.current.clientWidth
    const height = mapRef.current.clientHeight

    // Convert pixel position to a simulated lat/lng
    // This is just for demonstration - in a real app, you'd use the Google Maps API
    const lat = 37.7749 + ((height / 2 - y) / height) * 0.1
    const lng = -122.4194 + ((x - width / 2) / width) * 0.1

    return { lat: Number.parseFloat(lat.toFixed(6)), lng: Number.parseFloat(lng.toFixed(6)) }
  }

  const handleMapClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!mapRef.current) return

    const rect = mapRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top
    setPinPosition({ x, y })

    // Generate a simulated address based on the coordinates
    const coords = getSimulatedCoordinates(x, y)
    const simulatedAddress = `Simulated location (${coords.lat.toFixed(6)}, ${coords.lng.toFixed(6)})`
    setAddress(simulatedAddress)

    // Call the callback with the simulated location data
    if (onPinDrop) {
      onPinDrop({
        lat: coords.lat,
        lng: coords.lng,
        address: simulatedAddress,
      })
    }
  }

  const clearPin = () => {
    setPinPosition(null)
    setAddress(null)

    // Call the callback with empty data
    if (onPinDrop) {
      onPinDrop({ lat: 0, lng: 0, address: "" })
    }
  }

  const handleSearch = () => {
    if (!searchValue.trim()) return

    // Simulate a search by placing the pin in the center
    if (mapRef.current) {
      const width = mapRef.current.clientWidth
      const height = mapRef.current.clientHeight
      const x = width / 2
      const y = height / 2

      setPinPosition({ x, y })

      // Generate a simulated address that includes the search term
      const coords = getSimulatedCoordinates(x, y)
      const simulatedAddress = `${searchValue} (simulated: ${coords.lat.toFixed(6)}, ${coords.lng.toFixed(6)})`
      setAddress(simulatedAddress)

      // Call the callback with the simulated location data
      if (onPinDrop) {
        onPinDrop({
          lat: coords.lat,
          lng: coords.lng,
          address: simulatedAddress,
        })
      }
    }
  }

  const getCurrentLocation = () => {
    // Simulate getting current location by placing the pin slightly off-center
    if (mapRef.current) {
      const width = mapRef.current.clientWidth
      const height = mapRef.current.clientHeight
      const x = width / 2 + (Math.random() * 50 - 25)
      const y = height / 2 + (Math.random() * 50 - 25)

      setPinPosition({ x, y })

      // Generate a simulated address for the "current location"
      const coords = getSimulatedCoordinates(x, y)
      const simulatedAddress = `Your current location (simulated: ${coords.lat.toFixed(6)}, ${coords.lng.toFixed(6)})`
      setAddress(simulatedAddress)

      // Call the callback with the simulated location data
      if (onPinDrop) {
        onPinDrop({
          lat: coords.lat,
          lng: coords.lng,
          address: simulatedAddress,
        })
      }
    }
  }

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            placeholder="Search for a location"
            className="pr-10"
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          />
          {searchValue && (
            <button
              className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              onClick={() => setSearchValue("")}
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <Button variant="outline" size="icon" onClick={handleSearch} title="Search location">
          <Search className="h-4 w-4" />
        </Button>
        <Button variant="outline" size="icon" onClick={getCurrentLocation} title="Use current location">
          <Locate className="h-4 w-4" />
        </Button>
      </div>

      <div
        ref={mapRef}
        className="relative rounded-md overflow-hidden border border-gray-200 cursor-pointer"
        style={{ height }}
        onClick={handleMapClick}
      >
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url('${mapImage}')` }}>
          {pinPosition && (
            <div
              className="absolute"
              style={{
                left: `${pinPosition.x}px`,
                top: `${pinPosition.y}px`,
                transform: "translate(-50%, -100%)",
              }}
            >
              <MapPin className="h-8 w-8 text-[#ef4444] drop-shadow-md" />
            </div>
          )}
        </div>
        {!pinPosition && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4 bg-black/5">
            <MapPin className="h-8 w-8 text-[#6b7280] mb-2" />
            <p className="text-sm text-[#6b7280]">Tap anywhere on the map to drop a pin</p>
            <p className="text-xs text-[#6b7280] mt-1">(Simplified map - Google Maps API not available)</p>
          </div>
        )}
      </div>

      {address && (
        <div className="flex items-center justify-between bg-gray-50 p-3 rounded-md border border-gray-200">
          <div className="flex items-start gap-2">
            <MapPin className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium">Dropped Pin</p>
              <p className="text-xs text-gray-500">{address}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={clearPin} className="h-8 text-gray-500 hover:text-gray-700">
            <X className="h-4 w-4 mr-1" />
            Clear
          </Button>
        </div>
      )}
    </div>
  )
}
