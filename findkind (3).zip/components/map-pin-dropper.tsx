"use client"

import type React from "react"
import { useState } from "react"
import { MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"

export function MapPinDropper() {
  const [pinPosition, setPinPosition] = useState<{ x: number; y: number } | null>(null)
  const [address, setAddress] = useState<string | null>(null)

  const handleMapClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top
    setPinPosition({ x, y })

    // Simulate getting an address
    setAddress("Simulated location (Google Maps API not available)")
  }

  const clearPin = () => {
    setPinPosition(null)
    setAddress(null)
  }

  return (
    <div className="space-y-3">
      <div className="relative aspect-[4/3] bg-[#f3f4f6] rounded-md overflow-hidden border border-gray-200">
        <div
          className="absolute inset-0 bg-[url('/map-background.jpg')] bg-cover bg-center cursor-pointer"
          onClick={handleMapClick}
        >
          {pinPosition && (
            <div
              className="absolute"
              style={{
                left: `${pinPosition.x}px`,
                top: `${pinPosition.y}px`,
                transform: "translate(-50%, -100%)",
              }}
            >
              <MapPin className="h-8 w-8 text-[#ef4444] drop-shadow-md" />
            </div>
          )}
        </div>
        {!pinPosition && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4">
            <MapPin className="h-8 w-8 text-[#6b7280] mb-2" />
            <p className="text-sm text-[#6b7280]">Tap anywhere on the map to drop a pin</p>
            <p className="text-xs text-[#6b7280] mt-1">(Simplified map - Google Maps API not available)</p>
          </div>
        )}
      </div>

      {address && (
        <div className="flex items-center justify-between bg-gray-50 p-3 rounded-md border border-gray-200">
          <div className="flex items-start gap-2">
            <MapPin className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium">Dropped Pin</p>
              <p className="text-xs text-gray-500">{address}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={clearPin} className="h-8 text-gray-500 hover:text-gray-700">
            Clear
          </Button>
        </div>
      )}
    </div>
  )
}
